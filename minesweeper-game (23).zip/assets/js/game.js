// Mayın Tarlası Oyun JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // DOM elementleri
  const gameBoard = document.getElementById("game-board")
  const faceButton = document.getElementById("face-button")
  const newGameBtn = document.getElementById("new-game-btn")
  const difficultySelect = document.getElementById("difficulty-select")
  const customSettingsBtn = document.getElementById("custom-settings-btn")
  const customSettingsPanel = document.getElementById("custom-settings-panel")
  const cancelCustomSettings = document.getElementById("cancel-custom-settings")
  const themeToggle = document.getElementById("theme-toggle")
  const soundToggle = document.getElementById("sound-toggle")
  const pauseToggle = document.getElementById("pause-toggle")
  const hintBtn = document.getElementById("hint-btn")
  const powerUpBtn = document.getElementById("power-up-btn")

  // Oyun durumu
  let gameState = gameBoard ? gameBoard.dataset.state : "playing"
  let soundEnabled = true
  let isPaused = false

  // Ses efektleri
  const sounds = {
    click: new Audio("assets/sounds/click.mp3"),
    flag: new Audio("assets/sounds/flag.mp3"),
    win: new Audio("assets/sounds/win.mp3"),
    lose: new Audio("assets/sounds/lose.mp3"),
    hint: new Audio("assets/sounds/hint.mp3"),
    powerUp: new Audio("assets/sounds/power-up.mp3"),
  }

  // Ses çalma fonksiyonu
  function playSound(sound) {
    if (soundEnabled && sounds[sound]) {
      sounds[sound].currentTime = 0
      sounds[sound].play().catch((e) => console.log("Ses çalma hatası:", e))
    }
  }

  // Tema değiştirme
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const isDarkMode = document.body.classList.contains("dark-mode")
      document.body.classList.toggle("dark-mode")
      document.body.classList.toggle("light-mode")

      // Cookie'ye kaydet
      document.cookie = `dark_mode=${!isDarkMode}; path=/; max-age=31536000`
    })
  }

  // Ses açma/kapama
  if (soundToggle) {
    soundToggle.addEventListener("click", function () {
      soundEnabled = !soundEnabled
      this.dataset.enabled = soundEnabled

      // İkon değiştir
      if (soundEnabled) {
        this.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15.536a5 5 0 001.414 1.414m2.828-9.9a9 9 0 012.828-2.828"></path>
                </svg>`
      } else {
        this.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15.536a5 5 0 001.414 1.414m2.828-9.9a9 9 0 012.828-2.828"></path>
                </svg>`
      }
    })
  }

  // Oyunu duraklat/devam ettir
  if (pauseToggle) {
    pauseToggle.addEventListener("click", function () {
      isPaused = !isPaused

      // İkon değiştir
      if (isPaused) {
        this.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>`

        // Oyunu duraklat
        fetch("api/pause_game.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              faceButton.textContent = "😴"
              faceButton.dataset.face = "paused"
              gameState = "paused"
            }
          })
      } else {
        this.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>`

        // Oyunu devam ettir
        fetch("api/resume_game.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              faceButton.textContent = "🙂"
              faceButton.dataset.face = "playing"
              gameState = "playing"
            }
          })
      }
    })
  }

  // Yeni oyun başlat
  if (newGameBtn) {
    newGameBtn.addEventListener("click", () => {
      window.location.href = "game.php?new_game=1"
    })
  }

  // Zorluk seviyesi değiştirme
  if (difficultySelect) {
    difficultySelect.addEventListener("change", function () {
      const selectedDifficulty = this.value

      // Özel ayarlar panelini göster/gizle
      if (selectedDifficulty === "custom" && customSettingsPanel) {
        customSettingsPanel.style.display = "block"
      } else {
        // Zorluk seviyesini değiştir
        const formData = new FormData()
        formData.append("difficulty", selectedDifficulty)

        fetch("api/change_difficulty.php", {
          method: "POST",
          body: formData,
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              // Sayfayı yenile
              window.location.href = "game.php?new_game=1"
            } else {
              console.error("Zorluk seviyesi değiştirilemedi:", data.message)
            }
          })
          .catch((error) => {
            console.error("Hata:", error)
          })
      }
    })
  }

  // Oyun tahtası grid ayarlarını güncelle
  function updateGameBoardGrid(rows, cols) {
    if (gameBoard) {
      gameBoard.style.setProperty("--cols", cols)
      gameBoard.dataset.rows = rows
      gameBoard.dataset.cols = cols
    }
  }

  // Özel ayarlar paneli
  if (customSettingsBtn) {
    customSettingsBtn.addEventListener("click", () => {
      customSettingsPanel.style.display = "block"
    })
  }

  if (cancelCustomSettings) {
    cancelCustomSettings.addEventListener("click", () => {
      customSettingsPanel.style.display = "none"
    })
  }

  // Özel ayarlar formu
  const customSettingsForm = document.getElementById("custom-settings-form")
  if (customSettingsForm) {
    const rowsInput = customSettingsForm.querySelector('input[name="rows"]')
    const colsInput = customSettingsForm.querySelector('input[name="cols"]')
    const minesInput = customSettingsForm.querySelector('input[name="mines"]')
    const previewSize = document.getElementById("preview-size")
    const previewMines = document.getElementById("preview-mines")
    const previewDifficulty = document.getElementById("preview-difficulty")

    // Önizleme güncelleme
    function updatePreview() {
      const rows = Number.parseInt(rowsInput.value) || 10
      const cols = Number.parseInt(colsInput.value) || 10
      const mines = Number.parseInt(minesInput.value) || 10
      const totalCells = rows * cols
      const maxMines = Math.floor(totalCells * 0.9) // Max %90 mayın

      // Mayın sayısını sınırla
      if (mines > maxMines) {
        minesInput.value = maxMines
      }

      // Önizleme güncelle
      if (previewSize) previewSize.textContent = `${rows}x${cols}`
      if (previewMines) previewMines.textContent = minesInput.value
      if (previewDifficulty) {
        const difficulty = Math.round((mines / totalCells) * 100)
        previewDifficulty.textContent = `${difficulty}%`
      }

      // Grid ayarlarını güncelle
      updateGameBoardGrid(rows, cols)
    }

    rowsInput.addEventListener("input", updatePreview)
    colsInput.addEventListener("input", updatePreview)
    minesInput.addEventListener("input", updatePreview)
  }

  // Oyun tahtası
  if (gameBoard) {
    // Hücre tıklama olayları
    gameBoard.addEventListener("click", (e) => {
      if (gameState !== "playing" || isPaused) return

      const cell = e.target.closest(".game-cell")
      if (!cell) return

      const row = Number.parseInt(cell.dataset.row)
      const col = Number.parseInt(cell.dataset.col)

      // Hücre aç
      revealCell(row, col)
    })

    // Sağ tık ile bayrak koyma
    gameBoard.addEventListener("contextmenu", (e) => {
      e.preventDefault()
      if (gameState !== "playing" || isPaused) return

      const cell = e.target.closest(".game-cell")
      if (!cell) return

      const row = Number.parseInt(cell.dataset.row)
      const col = Number.parseInt(cell.dataset.col)

      // Bayrak koy/kaldır
      toggleFlag(row, col)
    })
  }

  // Face butonu
  if (faceButton) {
    faceButton.addEventListener("click", () => {
      window.location.href = "game.php?new_game=1"
    })
  }

  // İpucu butonu
  if (hintBtn) {
    hintBtn.addEventListener("click", function () {
      if (gameState !== "playing" || isPaused) return

      fetch("api/get_hint.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success && data.hint) {
            playSound("hint")

            // İpucu hücresini vurgula
            const row = data.hint.row
            const col = data.hint.col
            const cell = document.querySelector(`.game-cell[data-row="${row}"][data-col="${col}"]`)

            if (cell) {
              cell.classList.add("hint-highlight")
              setTimeout(() => {
                cell.classList.remove("hint-highlight")
              }, 3000)
            }

            // İpucu sayısını güncelle
            const hintsLeft = 3 - data.hints_used
            this.innerHTML = `
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                        </svg>
                        İpucu (${hintsLeft})
                    `

            if (hintsLeft <= 0) {
              this.disabled = true
            }
          }
        })
    })
  }

  // Güvenli açma butonu (Power-up)
  if (powerUpBtn) {
    powerUpBtn.addEventListener("click", function () {
      if (gameState !== "playing" || isPaused) return

      fetch("api/use_power_up.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          power: this.dataset.power,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            playSound("powerUp")

            // Güvenli hücreyi aç
            if (data.cell) {
              const row = data.cell.row
              const col = data.cell.col

              // Hücreyi otomatik aç
              revealCell(row, col)

              // Efekt göster
              const cell = document.querySelector(`.game-cell[data-row="${row}"][data-col="${col}"]`)
              if (cell) {
                cell.classList.add("power-up-active")
                setTimeout(() => {
                  cell.classList.remove("power-up-active")
                }, 1000)
              }
            }

            // Power-up sayısını güncelle
            this.disabled = true
            setTimeout(() => {
              this.disabled = false
            }, 10000) // 10 saniye cooldown
          }
        })
    })
  }

  // Hücre açma fonksiyonu
  function revealCell(row, col) {
    fetch("api/reveal_cell.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        row: row,
        col: col,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          playSound("click")
          updateGameBoard(data)

          // Oyun durumunu güncelle
          if (data.game_state === "won") {
            gameState = "won"
            faceButton.textContent = "😎"
            faceButton.dataset.face = "won"
            playSound("win")

            // Kazanma mesajı göster
            setTimeout(() => {
              window.location.reload()
            }, 1500)
          } else if (data.game_state === "lost") {
            gameState = "lost"
            faceButton.textContent = "😵"
            faceButton.dataset.face = "lost"
            playSound("lose")

            // Patlama efekti
            const cell = document.querySelector(`.game-cell[data-row="${row}"][data-col="${col}"]`)
            if (cell) {
              createExplosion(cell)
            }

            // Kaybetme mesajı göster
            setTimeout(() => {
              window.location.reload()
            }, 1500)
          }

          // Combo efekti
          if (data.combo && data.combo > 1) {
            const cell = document.querySelector(`.game-cell[data-row="${row}"][data-col="${col}"]`)
            if (cell) {
              createComboText(cell, data.combo)
            }

            // Combo sayısını güncelle
            const comboCount = document.getElementById("combo-count")
            if (comboCount) {
              comboCount.textContent = data.combo
            }
          }

          // Skoru güncelle
          const gameScore = document.getElementById("game-score")
          if (gameScore && data.score) {
            gameScore.textContent = data.score
          }

          // Tamamlanma yüzdesini güncelle
          if (data.revealed_count) {
            const completionPercentage = document.getElementById("completion-percentage")
            if (completionPercentage) {
              const rows = Number.parseInt(gameBoard.dataset.rows)
              const cols = Number.parseInt(gameBoard.dataset.cols)
              const mines = Number.parseInt(gameBoard.dataset.mines)
              const totalSafeCells = rows * cols - mines
              const revealedCells = document.querySelectorAll(".cell-revealed").length
              const percentage = Math.round((revealedCells / totalSafeCells) * 100)
              completionPercentage.textContent = `${percentage}%`
            }
          }
        }
      })
  }

  // Bayrak koyma/kaldırma fonksiyonu
  function toggleFlag(row, col) {
    fetch("api/toggle_flag.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        row: row,
        col: col,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          playSound("flag")

          // Hücreyi güncelle
          const cell = document.querySelector(`.game-cell[data-row="${row}"][data-col="${col}"]`)
          if (cell) {
            if (data.board[row][col].is_flagged) {
              cell.classList.add("cell-flagged")
              cell.textContent = "🚩"
            } else {
              cell.classList.remove("cell-flagged")
              cell.textContent = ""
            }
          }

          // Kalan mayın sayısını güncelle
          const minesLeft = document.getElementById("mines-left")
          if (minesLeft && data.mines_left !== undefined) {
            minesLeft.textContent = data.mines_left
          }
        }
      })
  }

  // Oyun tahtasını güncelleme
  function updateGameBoard(data) {
    if (!data.board) return

    for (let r = 0; r < data.board.length; r++) {
      for (let c = 0; c < data.board[r].length; c++) {
        const cell = document.querySelector(`.game-cell[data-row="${r}"][data-col="${c}"]`)
        if (!cell) continue

        const cellData = data.board[r][c]

        // Hücre sınıflarını güncelle
        cell.className = "game-cell"

        if (cellData.is_revealed) {
          if (cellData.is_mine) {
            cell.classList.add("cell-mine")
            cell.innerHTML = "💣" // innerHTML kullan
          } else {
            cell.classList.add("cell-revealed")
            if (cellData.neighbor_mines > 0) {
              cell.classList.add(`cell-number-${cellData.neighbor_mines}`)
              cell.textContent = cellData.neighbor_mines
            } else {
              cell.textContent = ""
            }
          }
        } else {
          if (cellData.is_flagged) {
            cell.classList.add("cell-flagged")
            cell.innerHTML = "🚩" // innerHTML kullan
          } else {
            cell.classList.add("cell-hidden")
            cell.textContent = ""
          }
        }
      }
    }
  }

  // Patlama efekti oluşturma
  function createExplosion(element) {
    const explosion = document.createElement("div")
    explosion.className = "explosion"
    element.appendChild(explosion)

    // Parçacıklar
    for (let i = 0; i < 12; i++) {
      const particle = document.createElement("div")
      particle.className = "explosion-particle"

      // Rastgele yön
      const angle = Math.random() * Math.PI * 2
      const distance = 30 + Math.random() * 50
      const dx = Math.cos(angle) * distance
      const dy = Math.sin(angle) * distance

      particle.style.setProperty("--dx", `${dx}px`)
      particle.style.setProperty("--dy", `${dy}px`)

      explosion.appendChild(particle)
    }

    // Efekti temizle
    setTimeout(() => {
      if (explosion.parentNode) {
        explosion.parentNode.removeChild(explosion)
      }
    }, 1000)
  }

  // Combo efekti oluşturma
  function createComboText(element, combo) {
    const comboText = document.createElement("div")
    comboText.className = "combo-text"
    comboText.textContent = `${combo}x Combo!`
    element.appendChild(comboText)

    // Efekti temizle
    setTimeout(() => {
      if (comboText.parentNode) {
        comboText.parentNode.removeChild(comboText)
      }
    }, 1000)
  }

  // Oyun süresini güncelleme
  function updateGameTime() {
    const gameTime = document.getElementById("game-time")
    if (!gameTime || gameState !== "playing" || isPaused) return

    fetch("api/get_game_state.php")
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          gameTime.textContent = data.time_formatted

          // Skoru güncelle
          const gameScore = document.getElementById("game-score")
          if (gameScore && data.score) {
            gameScore.textContent = data.score
          }
        }
      })
  }

  // Oyun süresini periyodik olarak güncelle
  if (gameState === "playing") {
    setInterval(updateGameTime, 1000)
  }
})
