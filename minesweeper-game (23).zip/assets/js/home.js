// Ana sayfa JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Tema değiştirme
  const themeToggle = document.getElementById("theme-toggle")
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const body = document.body
      const isDark = body.classList.contains("dark-mode")

      if (isDark) {
        body.classList.remove("dark-mode")
        body.classList.add("light-mode")
        setCookie("dark_mode", "false", 30)
      } else {
        body.classList.remove("light-mode")
        body.classList.add("dark-mode")
        setCookie("dark_mode", "true", 30)
      }
    })
  }

  // Parçacık animasyonu
  createParticles()

  // Form animasyonu
  const form = document.querySelector("form")
  const input = document.querySelector('input[name="nickname"]')

  if (form && input) {
    input.addEventListener("focus", function () {
      this.style.transform = "scale(1.02)"
    })

    input.addEventListener("blur", function () {
      this.style.transform = "scale(1)"
    })

    form.addEventListener("submit", (e) => {
      const nickname = input.value.trim()
      if (!nickname) {
        e.preventDefault()
        input.style.borderColor = "#f44336"
        input.focus()
        return
      }

      // Yükleme animasyonu
      const button = form.querySelector("button")
      if (button) {
        button.innerHTML =
          '<svg class="w-5 h-5 mr-2 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>Yükleniyor...'
        button.disabled = true
      }
    })
  }

  // Feature card hover efektleri
  const featureCards = document.querySelectorAll(".feature-card")
  featureCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-5px) scale(1.02)"
    })

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0) scale(1)"
    })
  })
})

// Parçacık oluşturma
function createParticles() {
  const container = document.querySelector(".particles-container")
  if (!container) return

  for (let i = 0; i < 15; i++) {
    const particle = document.createElement("div")
    particle.className = "particle"
    particle.style.left = Math.random() * 100 + "%"
    particle.style.top = Math.random() * 100 + "%"
    particle.style.animationDelay = Math.random() * 2 + "s"
    particle.style.animationDuration = 4 + Math.random() * 2 + "s"
    container.appendChild(particle)
  }
}

// Cookie yardımcı fonksiyonu
function setCookie(name, value, days) {
  const expires = new Date()
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000)
  document.cookie = name + "=" + value + ";expires=" + expires.toUTCString() + ";path=/"
}

function getCookie(name) {
  const nameEQ = name + "="
  const ca = document.cookie.split(";")
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === " ") c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}
