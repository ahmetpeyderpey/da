// Liderlik tablosu JavaScript
document.addEventListener("DOMContentLoaded", () => {
  setupEventListeners()
  animateLeaderboard()
})

function setupEventListeners() {
  // Tema değiştirme
  const themeToggle = document.getElementById("theme-toggle")
  if (themeToggle) {
    themeToggle.addEventListener("click", toggleTheme)
  }

  // Leaderboard satır hover efektleri
  const rows = document.querySelectorAll(".leaderboard-row, .leaderboard-row-top")
  rows.forEach((row) => {
    row.addEventListener("mouseenter", function () {
      this.style.transform = "translateX(10px) scale(1.02)"
    })

    row.addEventListener("mouseleave", function () {
      this.style.transform = "translateX(0) scale(1)"
    })
  })
}

function animateLeaderboard() {
  const rows = document.querySelectorAll(".leaderboard-row, .leaderboard-row-top")
  rows.forEach((row, index) => {
    row.style.opacity = "0"
    row.style.transform = "translateX(-20px)"

    setTimeout(() => {
      row.style.transition = "all 0.5s ease"
      row.style.opacity = "1"
      row.style.transform = "translateX(0)"
    }, index * 100)
  })
}

function toggleTheme() {
  const body = document.body
  const isDark = body.classList.contains("dark-mode")

  if (isDark) {
    body.classList.remove("dark-mode")
    body.classList.add("light-mode")
    setCookie("dark_mode", "false", 30)
  } else {
    body.classList.remove("light-mode")
    body.classList.add("dark-mode")
    setCookie("dark_mode", "true", 30)
  }
}

// Cookie yardımcı fonksiyonları
function setCookie(name, value, days) {
  const expires = new Date()
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000)
  document.cookie = name + "=" + value + ";expires=" + expires.toUTCString() + ";path=/"
}

function getCookie(name) {
  const nameEQ = name + "="
  const ca = document.cookie.split(";")
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === " ") c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}
