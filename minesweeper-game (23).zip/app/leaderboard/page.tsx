"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Home, Trophy, Medal, Award, Clock, Target, Sun, Moon } from "lucide-react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"

type Score = {
  nickname: string
  difficulty: string
  time: number
  score: number
  date: string
}

export default function LeaderboardPage() {
  const router = useRouter()
  const [scores, setScores] = useState<Score[]>([])
  const [filter, setFilter] = useState<"all" | "easy" | "medium" | "hard">("all")
  const [isDarkMode, setIsDarkMode] = useState(true)

  useEffect(() => {
    const savedScores = JSON.parse(localStorage.getItem("minesweeperScores") || "[]")
    setScores(savedScores)
  }, [])

  const filteredScores = scores.filter((score) => filter === "all" || score.difficulty === filter)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getDifficultyBadge = (difficulty: string) => {
    const configs = {
      easy: { bg: "bg-[#4caf50]", label: "Kolay" },
      medium: { bg: "bg-[#ffc107]", label: "Orta" },
      hard: { bg: "bg-[#f44336]", label: "Zor" },
    }
    const config = configs[difficulty as keyof typeof configs]
    return <Badge className={`${config.bg} text-white border-0`}>{config.label}</Badge>
  }

  const getRankIcon = (index: number) => {
    const icons = [
      <Trophy key="trophy" className="w-6 h-6 text-[#ffc107]" />,
      <Medal key="medal" className="w-6 h-6 text-gray-400" />,
      <Award key="award" className="w-6 h-6 text-amber-600" />,
    ]

    return (
      icons[index] || (
        <span
          className={`w-6 h-6 flex items-center justify-center font-bold ${
            isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"
          }`}
        >
          {index + 1}
        </span>
      )
    )
  }

  return (
    <div className={`min-h-screen transition-all duration-500 p-4 ${isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-100"}`}>
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <motion.div
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                onClick={() => router.push("/")}
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                    : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                } transition-all duration-300`}
              >
                <Home className="w-4 h-4 mr-2" />
                Ana Sayfa
              </Button>
            </motion.div>
            <motion.h1
              className={`text-4xl font-bold flex items-center gap-2 ${
                isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"
              }`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <Trophy className="w-8 h-8 text-[#ffc107]" />
              Liderlik Tablosu
            </motion.h1>
          </div>

          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`${
                isDarkMode
                  ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                  : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
              } transition-all duration-300`}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
          </motion.div>
        </motion.div>

        {/* Filter Buttons */}
        <motion.div
          className="flex flex-wrap gap-2 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          {[
            { key: "all", label: "Tümü" },
            { key: "easy", label: "Kolay" },
            { key: "medium", label: "Orta" },
            { key: "hard", label: "Zor" },
          ].map((level, index) => (
            <motion.div
              key={level.key}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + index * 0.1, duration: 0.3 }}
            >
              <Button
                variant={filter === level.key ? "default" : "outline"}
                onClick={() => setFilter(level.key as any)}
                className={
                  filter === level.key
                    ? "bg-[#2196f3] hover:bg-[#1976d2] text-white"
                    : `${
                        isDarkMode
                          ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                          : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                      } transition-all duration-300`
                }
              >
                {level.label}
              </Button>
            </motion.div>
          ))}
        </motion.div>

        {/* Statistics Cards */}
        <motion.div
          className="grid md:grid-cols-3 gap-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          {[
            {
              icon: Target,
              value: scores.length,
              label: "Toplam Oyun",
              color: "text-[#4caf50]",
            },
            {
              icon: Trophy,
              value: scores.length > 0 ? Math.max(...scores.map((s) => s.score)).toLocaleString() : "0",
              label: "En Yüksek Skor",
              color: "text-[#ffc107]",
            },
            {
              icon: Clock,
              value: scores.length > 0 ? formatTime(Math.min(...scores.map((s) => s.time))) : "00:00",
              label: "En Hızlı Süre",
              color: "text-[#2196f3]",
            },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              whileHover={{ scale: 1.05, y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
            >
              <Card
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                    : "bg-white/80 backdrop-blur border-gray-200/50"
                } transition-all duration-300 hover:shadow-lg`}
              >
                <CardContent className="p-4 text-center">
                  <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                  <div className={`text-2xl font-bold ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                    {stat.value}
                  </div>
                  <div className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>{stat.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Leaderboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <Card
            className={`${
              isDarkMode
                ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                : "bg-white/80 backdrop-blur border-gray-200/50"
            } shadow-xl`}
          >
            <CardHeader>
              <CardTitle className={`text-center text-2xl ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                🏆 En İyi Skorlar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AnimatePresence mode="wait">
                {filteredScores.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="text-center py-8"
                  >
                    <Trophy
                      className={`w-16 h-16 mx-auto mb-4 opacity-50 ${isDarkMode ? "text-gray-400" : "text-gray-300"}`}
                    />
                    <p className={`text-xl mb-2 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                      Henüz skor yok!
                    </p>
                    <p className={`mb-4 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                      İlk skorunu kaydetmek için oyun oynamaya başla.
                    </p>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        onClick={() => router.push("/game")}
                        className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] transition-all duration-300"
                      >
                        Oyuna Başla
                      </Button>
                    </motion.div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="scores"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-3"
                  >
                    {filteredScores.slice(0, 20).map((score, index) => (
                      <motion.div
                        key={`${score.nickname}-${score.date}-${index}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05, duration: 0.3 }}
                        whileHover={{ scale: 1.02, x: 5 }}
                        className={`flex items-center justify-between p-4 rounded-lg ${
                          index < 3
                            ? isDarkMode
                              ? "bg-gradient-to-r from-[#ffc107]/20 to-[#ff9800]/20 border border-[#ffc107]/30"
                              : "bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200"
                            : isDarkMode
                              ? "bg-[#1e1e2f]/50 border border-gray-700/30"
                              : "bg-white/50 border border-gray-200/50"
                        } transition-all duration-300`}
                      >
                        <div className="flex items-center gap-4">
                          {getRankIcon(index)}
                          <div>
                            <div className={`font-bold text-lg ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                              {score.nickname}
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              {getDifficultyBadge(score.difficulty)}
                              <span className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                                {new Date(score.date).toLocaleDateString("tr-TR")}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className={`font-bold text-xl ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                            {score.score.toLocaleString()}
                          </div>
                          <div
                            className={`text-sm flex items-center gap-1 ${
                              isDarkMode ? "text-blue-300" : "text-indigo-600"
                            }`}
                          >
                            <Clock className="w-3 h-3" />
                            {formatTime(score.time)}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </motion.div>

        {/* Back to Game Button */}
        <motion.div
          className="text-center mt-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => router.push("/game")}
              className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] text-lg px-8 py-3 transition-all duration-300"
            >
              🎮 Oyuna Dön
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}
