"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  RotateCcw,
  Home,
  Zap,
  Clock,
  Trophy,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Sun,
  Moon,
  Settings,
  Bot,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"

type CellState = {
  isMine: boolean
  isRevealed: boolean
  isFlagged: boolean
  neighborMines: number
}

type GameState = "playing" | "won" | "lost" | "paused"
type Difficulty = "easy" | "medium" | "hard" | "custom"

const DIFFICULTIES = {
  easy: { rows: 9, cols: 9, mines: 10 },
  medium: { rows: 16, cols: 16, mines: 40 },
  hard: { rows: 16, cols: 30, mines: 99 },
  custom: { rows: 10, cols: 10, mines: 15 }, // Default custom values
}

// Emoji faces for different states
const FACE_EMOJIS = {
  playing: "🙂",
  won: "😎",
  lost: "😵",
  paused: "😴",
  surprised: "😮",
}

export default function GamePage() {
  const router = useRouter()
  const [nickname, setNickname] = useState("")
  const [difficulty, setDifficulty] = useState<Difficulty>("medium")
  const [customSettings, setCustomSettings] = useState({ rows: 10, cols: 10, mines: 15 })
  const [showCustomSettings, setShowCustomSettings] = useState(false)
  const [board, setBoard] = useState<CellState[][]>([])
  const [gameState, setGameState] = useState<GameState>("playing")
  const [flagCount, setFlagCount] = useState(0)
  const [time, setTime] = useState(0)
  const [score, setScore] = useState(0)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [revealedCells, setRevealedCells] = useState(0)
  const [streak, setStreak] = useState(0)
  const [currentFace, setCurrentFace] = useState<keyof typeof FACE_EMOJIS>("playing")
  const [shakeScreen, setShakeScreen] = useState(false)
  const [confetti, setConfetti] = useState(false)
  const [revealAnimation, setRevealAnimation] = useState<{ row: number; col: number }[]>([])
  const [isAISolving, setIsAISolving] = useState(false)

  const timerRef = useRef<NodeJS.Timeout>()
  const audioContextRef = useRef<AudioContext>()

  const { rows, cols, mines } = difficulty === "custom" ? customSettings : DIFFICULTIES[difficulty]

  // Enhanced sound effects
  const playSound = useCallback(
    (frequency: number, duration: number, type: "sine" | "square" | "triangle" = "sine", volume = 0.1) => {
      if (!soundEnabled || !audioContextRef.current) return

      const oscillator = audioContextRef.current.createOscillator()
      const gainNode = audioContextRef.current.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContextRef.current.destination)

      oscillator.frequency.value = frequency
      oscillator.type = type
      gainNode.gain.setValueAtTime(volume, audioContextRef.current.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContextRef.current.currentTime + duration)

      oscillator.start(audioContextRef.current.currentTime)
      oscillator.stop(audioContextRef.current.currentTime + duration)
    },
    [soundEnabled],
  )

  // Play victory sound
  const playVictorySound = useCallback(() => {
    if (!soundEnabled || !audioContextRef.current) return

    // Victory melody
    const notes = [523, 659, 784, 1047] // C, E, G, C
    notes.forEach((freq, index) => {
      setTimeout(() => {
        playSound(freq, 0.3, "sine", 0.15)
      }, index * 150)
    })
  }, [soundEnabled, playSound])

  // Play explosion sound
  const playExplosionSound = useCallback(() => {
    if (!soundEnabled || !audioContextRef.current) return

    // Explosion effect
    playSound(100, 0.5, "square", 0.2)
    setTimeout(() => playSound(80, 0.3, "square", 0.15), 100)
    setTimeout(() => playSound(60, 0.2, "square", 0.1), 200)
  }, [soundEnabled, playSound])

  // Initialize game
  const initializeGame = useCallback(() => {
    const newBoard: CellState[][] = Array(rows)
      .fill(null)
      .map(() =>
        Array(cols)
          .fill(null)
          .map(() => ({
            isMine: false,
            isRevealed: false,
            isFlagged: false,
            neighborMines: 0,
          })),
      )

    // Place mines
    let minesPlaced = 0
    while (minesPlaced < mines) {
      const row = Math.floor(Math.random() * rows)
      const col = Math.floor(Math.random() * cols)

      if (!newBoard[row][col].isMine) {
        newBoard[row][col].isMine = true
        minesPlaced++
      }
    }

    // Calculate neighbor mine counts
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (!newBoard[r][c].isMine) {
          let count = 0
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr
              const nc = c + dc
              if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && newBoard[nr][nc].isMine) {
                count++
              }
            }
          }
          newBoard[r][c].neighborMines = count
        }
      }
    }

    setBoard(newBoard)
    setGameState("playing")
    setCurrentFace("playing")
    setFlagCount(0)
    setTime(0)
    setScore(0)
    setRevealedCells(0)
    setShakeScreen(false)
    setConfetti(false)
    setRevealAnimation([])
    setIsAISolving(false)

    // Start timer
    if (timerRef.current) clearInterval(timerRef.current)
    timerRef.current = setInterval(() => {
      setTime((prev) => prev + 1)
    }, 1000)
  }, [rows, cols, mines])

  // Reveal cell with animation
  const revealCell = useCallback(
    (row: number, col: number) => {
      if (gameState !== "playing" || board[row][col].isRevealed || board[row][col].isFlagged) return

      // Show surprised face temporarily
      setCurrentFace("surprised")
      setTimeout(() => setCurrentFace("playing"), 200)

      const newBoard = [...board]
      const cellsToReveal: [number, number][] = [[row, col]]
      const animationCells: { row: number; col: number }[] = []
      let newRevealedCount = 0

      while (cellsToReveal.length > 0) {
        const [r, c] = cellsToReveal.pop()!

        if (newBoard[r][c].isRevealed) continue

        newBoard[r][c].isRevealed = true
        newRevealedCount++
        animationCells.push({ row: r, col: c })

        if (newBoard[r][c].isMine) {
          setGameState("lost")
          setCurrentFace("lost")
          setShakeScreen(true)
          playExplosionSound()
          if (timerRef.current) clearInterval(timerRef.current)

          // Reveal all mines
          for (let mr = 0; mr < rows; mr++) {
            for (let mc = 0; mc < cols; mc++) {
              if (newBoard[mr][mc].isMine) {
                newBoard[mr][mc].isRevealed = true
              }
            }
          }

          setTimeout(() => setShakeScreen(false), 500)
          setBoard(newBoard)
          return
        }

        playSound(800 + newBoard[r][c].neighborMines * 100, 0.1, "sine", 0.05)

        // Auto-reveal empty cells
        if (newBoard[r][c].neighborMines === 0) {
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr
              const nc = c + dc
              if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && !newBoard[nr][nc].isRevealed) {
                cellsToReveal.push([nr, nc])
              }
            }
          }
        }
      }

      // Animate cell reveals
      setRevealAnimation(animationCells)
      setTimeout(() => setRevealAnimation([]), 500)

      setBoard(newBoard)
      setRevealedCells((prev) => prev + newRevealedCount)
      setScore((prev) => prev + newRevealedCount * 10)

      // Check win condition
      const totalCells = rows * cols
      if (revealedCells + newRevealedCount === totalCells - mines) {
        setGameState("won")
        setCurrentFace("won")
        setStreak((prev) => prev + 1)
        setConfetti(true)
        playVictorySound()
        if (timerRef.current) clearInterval(timerRef.current)

        // Save score
        const gameScore = {
          nickname,
          difficulty: difficulty === "custom" ? `Özel (${rows}x${cols}, ${mines} mayın)` : difficulty,
          time,
          score: score + newRevealedCount * 10,
          date: new Date().toISOString(),
        }

        const scores = JSON.parse(localStorage.getItem("minesweeperScores") || "[]")
        scores.push(gameScore)
        scores.sort((a: any, b: any) => b.score - a.score)
        localStorage.setItem("minesweeperScores", JSON.stringify(scores.slice(0, 100)))

        setTimeout(() => setConfetti(false), 3000)
      }
    },
    [
      board,
      gameState,
      rows,
      cols,
      mines,
      revealedCells,
      score,
      time,
      nickname,
      difficulty,
      playSound,
      playVictorySound,
      playExplosionSound,
    ],
  )

  // AI Solver with working auto-reveal
  const solveWithAI = useCallback(() => {
    if (gameState !== "playing" || isAISolving) return

    setIsAISolving(true)
    playSound(1200, 0.2, "sine", 0.1)

    const aiInterval = setInterval(() => {
      // Oyun durumu kontrolü
      if (gameState !== "playing" || !isAISolving) {
        clearInterval(aiInterval)
        setIsAISolving(false)
        return
      }

      // Açılmamış ve bayrak konmamış hücreleri bul
      const availableCells: [number, number][] = []

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (!board[r][c].isRevealed && !board[r][c].isFlagged && !board[r][c].isMine) {
            availableCells.push([r, c])
          }
        }
      }

      // Eğer açılabilir hücre varsa, rastgele birini aç
      if (availableCells.length > 0) {
        const randomIndex = Math.floor(Math.random() * availableCells.length)
        const [r, c] = availableCells[randomIndex]

        // Hücreyi aç
        setTimeout(() => {
          revealCell(r, c)
        }, 100)
      } else {
        // Açılabilir hücre kalmadıysa AI'ı durdur
        clearInterval(aiInterval)
        setIsAISolving(false)
      }
    }, 1000) // Her saniyede bir hamle
  }, [board, gameState, isAISolving, rows, cols, playSound, revealCell])

  // Stop AI function
  const stopAI = useCallback(() => {
    setIsAISolving(false)
    playSound(800, 0.1, "sine", 0.05)
  }, [playSound])

  // Toggle flag with animation
  const toggleFlag = useCallback(
    (row: number, col: number, e: React.MouseEvent) => {
      e.preventDefault()
      if (gameState !== "playing" || board[row][col].isRevealed) return

      const newBoard = [...board]
      newBoard[row][col].isFlagged = !newBoard[row][col].isFlagged

      setBoard(newBoard)
      setFlagCount((prev) => (newBoard[row][col].isFlagged ? prev + 1 : prev - 1))
      playSound(newBoard[row][col].isFlagged ? 600 : 400, 0.1, "triangle", 0.08)
    },
    [board, gameState, playSound],
  )

  // Handle difficulty change
  const handleDifficultyChange = (newDifficulty: Difficulty) => {
    setDifficulty(newDifficulty)
    if (newDifficulty === "custom") {
      setShowCustomSettings(true)
    } else {
      setShowCustomSettings(false)
    }
  }

  // Handle custom settings change
  const handleCustomSettingsChange = (field: string, value: number) => {
    setCustomSettings((prev) => {
      const newSettings = { ...prev, [field]: value }

      // Validate settings
      const maxCells = newSettings.rows * newSettings.cols
      if (newSettings.mines >= maxCells) {
        newSettings.mines = Math.max(1, maxCells - 1)
      }

      return newSettings
    })
  }

  // Apply custom settings
  const applyCustomSettings = () => {
    setShowCustomSettings(false)
    initializeGame()
  }

  // Toggle pause
  const togglePause = useCallback(() => {
    if (gameState === "playing") {
      setGameState("paused")
      setCurrentFace("paused")
      if (timerRef.current) clearInterval(timerRef.current)
    } else if (gameState === "paused") {
      setGameState("playing")
      setCurrentFace("playing")
      timerRef.current = setInterval(() => {
        setTime((prev) => prev + 1)
      }, 1000)
    }
  }, [gameState])

  // Initialize on mount
  useEffect(() => {
    const savedNickname = localStorage.getItem("playerNickname")
    if (!savedNickname) {
      router.push("/")
      return
    }
    setNickname(savedNickname)

    // Create audio context
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()

    initializeGame()

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [router, initializeGame])

  // Restart game when difficulty changes (except custom)
  useEffect(() => {
    if (board.length > 0 && difficulty !== "custom") {
      initializeGame()
    }
  }, [difficulty, initializeGame])

  // AI durumu kontrolü
  useEffect(() => {
    if (gameState !== "playing") {
      setIsAISolving(false)
    }
  }, [gameState])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getCellContent = (cell: CellState) => {
    if (cell.isFlagged) return "🚩"
    if (!cell.isRevealed) return ""
    if (cell.isMine) return "💣"
    if (cell.neighborMines === 0) return ""
    return cell.neighborMines.toString()
  }

  const getCellClass = (cell: CellState, row: number, col: number) => {
    const isAnimating = revealAnimation.some((anim) => anim.row === row && anim.col === col)

    let baseClass = `w-8 h-8 md:w-10 md:h-10 border flex items-center justify-center text-sm md:text-base font-bold cursor-pointer transition-all duration-200 select-none `

    if (isDarkMode) {
      baseClass += `border-gray-600 `
      if (cell.isRevealed) {
        if (cell.isMine) {
          baseClass += `bg-[#f44336] text-white animate-pulse `
        } else {
          baseClass += `bg-[#3e3e4e] `
        }
      } else {
        baseClass += cell.isFlagged
          ? `bg-[#ffc107] hover:bg-[#ffb300] `
          : `bg-[#2e2e3e] hover:bg-[#3e3e4e] hover:brightness-110 `
      }
    } else {
      baseClass += `border-gray-400 `
      if (cell.isRevealed) {
        if (cell.isMine) {
          baseClass += `bg-red-500 text-white animate-pulse `
        } else {
          baseClass += `bg-gray-100 `
        }
      } else {
        baseClass += cell.isFlagged ? `bg-yellow-400 hover:bg-yellow-300 ` : `bg-gray-300 hover:bg-gray-200 `
      }
    }

    // Number colors
    if (cell.isRevealed && !cell.isMine && cell.neighborMines > 0) {
      const colors = [
        "",
        "text-blue-600",
        "text-green-600",
        "text-red-600",
        "text-purple-600",
        "text-yellow-600",
        "text-pink-600",
        "text-black",
        "text-gray-600",
      ]
      baseClass += colors[cell.neighborMines] || "text-black"
    }

    if (isAnimating) {
      baseClass += `animate-pulse scale-110 `
    }

    return baseClass
  }

  if (!nickname) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-100"}`}>
        <div className={`text-xl ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>Yükleniyor...</div>
      </div>
    )
  }

  return (
    <motion.div
      className={`min-h-screen transition-all duration-500 p-4 ${isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-100"}`}
      animate={shakeScreen ? { x: [-5, 5, -5, 5, 0] } : {}}
      transition={{ duration: 0.5 }}
    >
      {/* Confetti Effect */}
      <AnimatePresence>
        {confetti && (
          <div className="fixed inset-0 pointer-events-none z-50">
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-[#ffc107] rounded"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-10px`,
                }}
                initial={{ y: -10, rotate: 0, opacity: 1 }}
                animate={{
                  y: window.innerHeight + 10,
                  rotate: 360,
                  opacity: 0,
                }}
                transition={{
                  duration: 3 + Math.random() * 2,
                  delay: Math.random() * 2,
                }}
              />
            ))}
          </div>
        )}
      </AnimatePresence>

      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          className="flex flex-wrap items-center justify-between mb-6 gap-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                onClick={() => router.push("/")}
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                    : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                } transition-all duration-300`}
              >
                <Home className="w-4 h-4 mr-2" />
                Ana Sayfa
              </Button>
            </motion.div>
            <Badge
              variant="secondary"
              className={`text-lg px-3 py-1 ${
                isDarkMode
                  ? "bg-[#2e2e3e] text-[#ffc107] border-[#ffc107]/30"
                  : "bg-indigo-100 text-indigo-700 border-indigo-200"
              }`}
            >
              Merhaba, {nickname}! 👋
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            {[
              { icon: isDarkMode ? Sun : Moon, action: () => setIsDarkMode(!isDarkMode) },
              { icon: soundEnabled ? Volume2 : VolumeX, action: () => setSoundEnabled(!soundEnabled) },
              { icon: gameState === "paused" ? Play : Pause, action: togglePause },
            ].map((btn, index) => (
              <motion.div key={index} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={btn.action}
                  className={`${
                    isDarkMode
                      ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                      : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                  } transition-all duration-300`}
                >
                  <btn.icon className="w-4 h-4" />
                </Button>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Game Stats */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          {[
            { icon: Clock, value: formatTime(time), label: "Süre", color: "text-blue-400" },
            { icon: "🚩", value: mines - flagCount, label: "Mayın", color: "text-[#ffc107]" },
            { icon: Trophy, value: score, label: "Skor", color: "text-[#ffc107]" },
            { icon: Zap, value: streak, label: "Seri", color: "text-[#4caf50]" },
            {
              icon: "📊",
              value: `${Math.round((revealedCells / (rows * cols - mines)) * 100)}%`,
              label: "Tamamlanan",
              color: "text-purple-400",
            },
          ].map((stat, index) => (
            <motion.div key={stat.label} whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
              <Card
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                    : "bg-white/80 backdrop-blur border-gray-200/50"
                } transition-all duration-300 hover:shadow-lg`}
              >
                <CardContent className="p-3 text-center">
                  {typeof stat.icon === "string" ? (
                    <div className="text-2xl mb-1">{stat.icon}</div>
                  ) : (
                    <stat.icon className={`w-5 h-5 mx-auto mb-1 ${stat.color}`} />
                  )}
                  <div className={`font-bold ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>{stat.value}</div>
                  <div className={`text-xs ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>{stat.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Game Controls */}
        <motion.div
          className="flex flex-wrap items-center justify-between mb-6 gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <div className="flex items-center gap-2">
            <select
              value={difficulty}
              onChange={(e) => handleDifficultyChange(e.target.value as Difficulty)}
              className={`${
                isDarkMode ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5]" : "bg-white border-gray-300 text-gray-800"
              } rounded px-3 py-2 backdrop-blur transition-all duration-300`}
              disabled={gameState === "playing"}
            >
              <option value="easy">Kolay (9x9)</option>
              <option value="medium">Orta (16x16)</option>
              <option value="hard">Zor (16x30)</option>
              <option value="custom">Özel</option>
            </select>

            {difficulty === "custom" && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCustomSettings(!showCustomSettings)}
                  className={`${
                    isDarkMode
                      ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                      : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                  } transition-all duration-300`}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Ayarlar
                </Button>
              </motion.div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              {isAISolving ? (
                <Button
                  onClick={stopAI}
                  className="bg-gradient-to-r from-[#f44336] to-[#d32f2f] hover:from-[#d32f2f] hover:to-[#b71c1c] transition-all duration-300"
                >
                  <Bot className="w-4 h-4 mr-2" />
                  AI'ı Durdur
                </Button>
              ) : (
                <Button
                  onClick={solveWithAI}
                  disabled={gameState !== "playing"}
                  className="bg-gradient-to-r from-[#9c27b0] to-[#e91e63] hover:from-[#7b1fa2] hover:to-[#c2185b] transition-all duration-300"
                >
                  <Bot className="w-4 h-4 mr-2" />
                  AI Otomatik Çöz
                </Button>
              )}
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={initializeGame}
                className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] transition-all duration-300"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Yeni Oyun
              </Button>
            </motion.div>
          </div>
        </motion.div>

        {/* Custom Settings Panel */}
        <AnimatePresence>
          {showCustomSettings && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6"
            >
              <Card
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e]/90 backdrop-blur border-gray-600/30"
                    : "bg-white/90 backdrop-blur border-gray-200/50"
                } shadow-xl`}
              >
                <CardContent className="p-6">
                  <h3
                    className={`text-xl font-bold mb-4 text-center ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}
                  >
                    🎮 Özel Oyun Ayarları
                  </h3>

                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <Label className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                        Satır Sayısı (5-30)
                      </Label>
                      <Input
                        type="number"
                        min="5"
                        max="30"
                        value={customSettings.rows}
                        onChange={(e) =>
                          handleCustomSettingsChange(
                            "rows",
                            Math.max(5, Math.min(30, Number.parseInt(e.target.value) || 5)),
                          )
                        }
                        className={`mt-1 ${
                          isDarkMode
                            ? "bg-[#1e1e2f] border-gray-600 text-[#f5f5f5]"
                            : "bg-white border-gray-300 text-gray-800"
                        }`}
                      />
                    </div>

                    <div>
                      <Label className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                        Sütun Sayısı (5-50)
                      </Label>
                      <Input
                        type="number"
                        min="5"
                        max="50"
                        value={customSettings.cols}
                        onChange={(e) =>
                          handleCustomSettingsChange(
                            "cols",
                            Math.max(5, Math.min(50, Number.parseInt(e.target.value) || 5)),
                          )
                        }
                        className={`mt-1 ${
                          isDarkMode
                            ? "bg-[#1e1e2f] border-gray-600 text-[#f5f5f5]"
                            : "bg-white border-gray-300 text-gray-800"
                        }`}
                      />
                    </div>

                    <div>
                      <Label className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                        Mayın Sayısı (1-{Math.max(1, customSettings.rows * customSettings.cols - 1)})
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max={Math.max(1, customSettings.rows * customSettings.cols - 1)}
                        value={customSettings.mines}
                        onChange={(e) =>
                          handleCustomSettingsChange(
                            "mines",
                            Math.max(
                              1,
                              Math.min(
                                customSettings.rows * customSettings.cols - 1,
                                Number.parseInt(e.target.value) || 1,
                              ),
                            ),
                          )
                        }
                        className={`mt-1 ${
                          isDarkMode
                            ? "bg-[#1e1e2f] border-gray-600 text-[#f5f5f5]"
                            : "bg-white border-gray-300 text-gray-800"
                        }`}
                      />
                    </div>
                  </div>

                  <div className={`text-center mb-4 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                    <p>
                      <strong>Önizleme:</strong> {customSettings.rows}x{customSettings.cols} alan,{" "}
                      {customSettings.mines} mayın
                    </p>
                    <p className="text-sm">
                      Zorluk: {Math.round((customSettings.mines / (customSettings.rows * customSettings.cols)) * 100)}%
                      mayın yoğunluğu
                    </p>
                  </div>

                  <div className="flex justify-center gap-4">
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        onClick={applyCustomSettings}
                        className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] transition-all duration-300"
                      >
                        Oyunu Başlat
                      </Button>
                    </motion.div>

                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        variant="outline"
                        onClick={() => setShowCustomSettings(false)}
                        className={`${
                          isDarkMode
                            ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                            : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                        } transition-all duration-300`}
                      >
                        İptal
                      </Button>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Face Button */}
        <motion.div
          className="text-center mb-6"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          <motion.button
            className={`text-6xl p-4 rounded-full ${
              isDarkMode ? "bg-[#2e2e3e] hover:bg-[#3e3e4e]" : "bg-white hover:bg-gray-50"
            } shadow-lg transition-all duration-300`}
            onClick={initializeGame}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            animate={currentFace === "surprised" ? { scale: [1, 1.2, 1] } : {}}
          >
            {FACE_EMOJIS[currentFace]}
          </motion.button>
        </motion.div>

        {/* Game Status */}
        <AnimatePresence>
          {gameState !== "playing" && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6"
            >
              <Card
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e]/90 backdrop-blur border-gray-600/30"
                    : "bg-white/90 backdrop-blur border-gray-200/50"
                } shadow-xl`}
              >
                <CardContent className="p-4 text-center">
                  {gameState === "won" && (
                    <motion.div
                      className="text-[#4caf50] text-xl font-bold"
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 0.5, repeat: 3 }}
                    >
                      🎉 Tebrikler! Oyunu Kazandınız! 🎉
                    </motion.div>
                  )}
                  {gameState === "lost" && (
                    <motion.div
                      className="text-[#f44336] text-xl font-bold"
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ duration: 0.5, repeat: 2 }}
                    >
                      💥 Mayına Bastınız! Tekrar Deneyin! 💥
                    </motion.div>
                  )}
                  {gameState === "paused" && (
                    <div className="text-[#ffc107] text-xl font-bold">⏸️ Oyun Duraklatıldı</div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Game Board */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <Card
            className={`${
              isDarkMode
                ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                : "bg-white/80 backdrop-blur border-gray-200/50"
            } overflow-hidden shadow-2xl`}
          >
            <CardContent className="p-4">
              <div
                className={`inline-block mx-auto p-2 rounded-lg shadow-inner ${
                  isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-200"
                }`}
                style={{
                  display: "grid",
                  gridTemplateColumns: `repeat(${cols}, 1fr)`,
                  gap: "1px",
                  width: "fit-content", // Bu satırı değiştir
                }}
              >
                {board.map((row, rowIndex) =>
                  row.map((cell, colIndex) => (
                    <motion.button
                      key={`${rowIndex}-${colIndex}`}
                      className={getCellClass(cell, rowIndex, colIndex)}
                      onClick={() => revealCell(rowIndex, colIndex)}
                      onContextMenu={(e) => toggleFlag(rowIndex, colIndex, e)}
                      disabled={gameState === "paused"}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{
                        filter: gameState === "paused" ? "blur(4px)" : "none",
                      }}
                    >
                      {getCellContent(cell)}
                    </motion.button>
                  )),
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Instructions */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1, duration: 0.5 }}>
          <Card
            className={`mt-6 ${
              isDarkMode
                ? "bg-[#1e1e2f]/30 backdrop-blur border-gray-700/30"
                : "bg-indigo-50/50 backdrop-blur border-indigo-200/30"
            }`}
          >
            <CardContent className="p-4">
              <div className={`text-center ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                <p className="mb-2">
                  <strong>Nasıl Oynanır:</strong> Sol tık ile hücre aç, sağ tık ile bayrak koy/kaldır
                </p>
                <p className="text-sm">
                  💡 İpucu: Sayılar etrafındaki mayın sayısını gösterir. Özel zorluk seviyesi ile kendi oyununuzu
                  oluşturun!
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  )
}
