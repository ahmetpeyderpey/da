"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Gamepad2, Trophy, BarChart3, Sparkles, Volume2, Moon, Sun } from "lucide-react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"

export default function HomePage() {
  const [nickname, setNickname] = useState("")
  const [isAnimating, setIsAnimating] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Floating particles animation
    const interval = setInterval(() => {
      setIsAnimating(true)
      setTimeout(() => setIsAnimating(false), 3000)
    }, 6000)

    return () => clearInterval(interval)
  }, [])

  const handleStartGame = () => {
    if (nickname.trim()) {
      localStorage.setItem("playerNickname", nickname.trim())
      router.push("/game")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleStartGame()
    }
  }

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDarkMode ? "bg-[#1e1e2f]" : "bg-gradient-to-br from-blue-50 to-indigo-100"
      } relative overflow-hidden`}
    >
      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className={`absolute w-1 h-1 rounded-full ${isDarkMode ? "bg-white/20" : "bg-indigo-300/40"}`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.2, 0.8, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Theme Toggle */}
      <motion.div className="absolute top-6 right-6 z-10" whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          variant="outline"
          size="sm"
          onClick={toggleTheme}
          className={`${
            isDarkMode
              ? "bg-[#2e2e3e] border-gray-600 text-white hover:bg-[#3e3e4e]"
              : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          } transition-all duration-300`}
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>
      </motion.div>

      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex items-center justify-center">
        <div className="max-w-4xl w-full">
          {/* Header */}
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1
              className={`text-6xl font-bold mb-4 ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}
              animate={{
                textShadow: isAnimating ? "0 0 20px rgba(255, 193, 7, 0.5)" : "0 0 0px rgba(255, 193, 7, 0)",
              }}
              transition={{ duration: 0.5 }}
            >
              💣 MAYIN TARLASI 💣
            </motion.h1>
            <motion.p
              className={`text-xl mb-4 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              Modern ve Eğlenceli Mayın Tarlası Deneyimi
            </motion.p>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <Badge
                variant="secondary"
                className={`text-lg px-4 py-2 ${
                  isDarkMode
                    ? "bg-[#2e2e3e] text-[#ffc107] border-[#ffc107]/30"
                    : "bg-indigo-100 text-indigo-700 border-indigo-200"
                }`}
              >
                <Volume2 className="w-4 h-4 mr-2" />
                Sesli Oyun Deneyimi
              </Badge>
            </motion.div>
          </motion.div>

          {/* Main Card */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <Card
              className={`${
                isDarkMode
                  ? "bg-[#2e2e3e]/80 backdrop-blur-lg border-gray-600/30"
                  : "bg-white/80 backdrop-blur-lg border-gray-200/50"
              } shadow-2xl transition-all duration-300 hover:shadow-3xl`}
            >
              <CardHeader className="text-center">
                <CardTitle
                  className={`text-3xl flex items-center justify-center gap-2 ${
                    isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"
                  }`}
                >
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatDelay: 3 }}
                  >
                    <Sparkles className="w-8 h-8 text-[#ffc107]" />
                  </motion.div>
                  Oyuna Başla
                  <motion.div
                    animate={{ rotate: [0, -10, 10, 0] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatDelay: 3, delay: 0.5 }}
                  >
                    <Sparkles className="w-8 h-8 text-[#ffc107]" />
                  </motion.div>
                </CardTitle>
                <CardDescription className={`text-lg ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                  Nickname'ini gir ve eğlenceye başla!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <motion.div whileFocus={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
                    <Input
                      type="text"
                      placeholder="Nickname'ini gir..."
                      value={nickname}
                      onChange={(e) => setNickname(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className={`text-lg py-3 transition-all duration-300 ${
                        isDarkMode
                          ? "bg-[#1e1e2f] border-gray-600 text-[#f5f5f5] placeholder:text-gray-400 focus:border-[#ffc107] focus:ring-[#ffc107]/20"
                          : "bg-white border-gray-300 text-gray-800 placeholder:text-gray-500 focus:border-indigo-500 focus:ring-indigo-500/20"
                      }`}
                      maxLength={20}
                    />
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      onClick={handleStartGame}
                      disabled={!nickname.trim()}
                      className={`w-full text-lg py-3 transition-all duration-300 ${
                        isDarkMode
                          ? "bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] disabled:from-gray-600 disabled:to-gray-700"
                          : "bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                      } disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      <Gamepad2 className="w-5 h-5 mr-2" />
                      Oyunu Başlat
                    </Button>
                  </motion.div>
                </div>

                {/* Feature Cards */}
                <div className="grid md:grid-cols-3 gap-4 mt-8">
                  {[
                    {
                      icon: Trophy,
                      title: "Liderlik Tablosu",
                      desc: "En iyi skorları gör",
                      color: "text-[#ffc107]",
                      route: "/leaderboard",
                    },
                    {
                      icon: BarChart3,
                      title: "İstatistikler",
                      desc: "Performansını analiz et",
                      color: "text-[#4caf50]",
                      route: "/stats",
                    },
                    {
                      icon: Sparkles,
                      title: "AI Çözücü",
                      desc: "Yapay zeka ile çöz",
                      color: "text-[#9c27b0]",
                      route: null,
                    },
                  ].map((feature, index) => (
                    <motion.div
                      key={feature.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                      whileHover={{ scale: 1.05, y: -5 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Card
                        className={`${
                          isDarkMode
                            ? "bg-[#1e1e2f]/50 border-gray-700/30 hover:bg-[#2e2e3e]/50"
                            : "bg-white/50 border-gray-200/50 hover:bg-white/70"
                        } transition-all duration-300 cursor-pointer group`}
                        onClick={() => feature.route && router.push(feature.route)}
                      >
                        <CardContent className="p-4 text-center">
                          <motion.div
                            className={`w-8 h-8 mx-auto mb-2 ${feature.color}`}
                            whileHover={{ rotate: 360 }}
                            transition={{ duration: 0.5 }}
                          >
                            <feature.icon className="w-full h-full" />
                          </motion.div>
                          <h3
                            className={`font-semibold group-hover:${feature.color} transition-colors duration-300 ${
                              isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"
                            }`}
                          >
                            {feature.title}
                          </h3>
                          <p className={`text-sm ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                            {feature.desc}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {/* Game Features */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1, duration: 0.8 }}
                  className={`${isDarkMode ? "bg-[#1e1e2f]/30" : "bg-indigo-50/50"} rounded-lg p-4 mt-6 border ${
                    isDarkMode ? "border-gray-700/30" : "border-indigo-200/30"
                  }`}
                >
                  <h3 className={`font-semibold mb-3 text-center ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                    🎮 Oyun Özellikleri
                  </h3>
                  <div className={`grid grid-cols-2 gap-2 text-sm ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                    {[
                      "✨ Modern animasyonlar",
                      "🔊 Dinamik ses efektleri",
                      "🤖 AI otomatik çözücü",
                      "📊 Detaylı istatistikler",
                      "🏆 Liderlik tablosu",
                      "⚡ Smooth performans",
                    ].map((feature, index) => (
                      <motion.div
                        key={feature}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.2 + index * 0.1, duration: 0.5 }}
                        className="flex items-center"
                      >
                        {feature}
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Footer */}
          <motion.div
            className={`text-center mt-8 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 0.8 }}
          >
            <p>© 2024 MayinTarlasi.net - Modern Oyun Deneyimi</p>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
