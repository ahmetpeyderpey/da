"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Home, BarChart3, TrendingUp, Target, Clock, Trophy, Zap, Percent, Sun, Moon } from "lucide-react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"

type Score = {
  nickname: string
  difficulty: string
  time: number
  score: number
  date: string
}

type Stats = {
  totalGames: number
  totalScore: number
  averageTime: number
  bestScore: number
  fastestTime: number
  winRate: number
  gamesPerDifficulty: { [key: string]: number }
  averageScorePerDifficulty: { [key: string]: number }
  recentGames: Score[]
  streak: number
}

export default function StatsPage() {
  const router = useRouter()
  const [stats, setStats] = useState<Stats>({
    totalGames: 0,
    totalScore: 0,
    averageTime: 0,
    bestScore: 0,
    fastestTime: 0,
    winRate: 0,
    gamesPerDifficulty: {},
    averageScorePerDifficulty: {},
    recentGames: [],
    streak: 0,
  })
  const [isDarkMode, setIsDarkMode] = useState(true)

  useEffect(() => {
    const savedScores: Score[] = JSON.parse(localStorage.getItem("minesweeperScores") || "[]")

    if (savedScores.length === 0) {
      return
    }

    const totalGames = savedScores.length
    const totalScore = savedScores.reduce((sum, score) => sum + score.score, 0)
    const averageTime = Math.round(savedScores.reduce((sum, score) => sum + score.time, 0) / totalGames)
    const bestScore = Math.max(...savedScores.map((s) => s.score))
    const fastestTime = Math.min(...savedScores.map((s) => s.time))

    // Statistics by difficulty
    const gamesPerDifficulty: { [key: string]: number } = {}
    const scoresByDifficulty: { [key: string]: number[] } = {}

    savedScores.forEach((score) => {
      gamesPerDifficulty[score.difficulty] = (gamesPerDifficulty[score.difficulty] || 0) + 1
      if (!scoresByDifficulty[score.difficulty]) {
        scoresByDifficulty[score.difficulty] = []
      }
      scoresByDifficulty[score.difficulty].push(score.score)
    })

    const averageScorePerDifficulty: { [key: string]: number } = {}
    Object.keys(scoresByDifficulty).forEach((difficulty) => {
      const scores = scoresByDifficulty[difficulty]
      averageScorePerDifficulty[difficulty] = Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length)
    })

    // Recent games
    const recentGames = savedScores.slice(-10).reverse()

    // Streak calculation
    let streak = 0
    for (let i = savedScores.length - 1; i >= 0; i--) {
      if (savedScores[i].score > 0) {
        streak++
      } else {
        break
      }
    }

    setStats({
      totalGames,
      totalScore,
      averageTime,
      bestScore,
      fastestTime,
      winRate: 100, // All recorded games are won games
      gamesPerDifficulty,
      averageScorePerDifficulty,
      recentGames,
      streak,
    })
  }, [])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getDifficultyLabel = (difficulty: string) => {
    const labels = { easy: "Kolay", medium: "Orta", hard: "Zor" }
    return labels[difficulty as keyof typeof labels] || difficulty
  }

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      easy: isDarkMode ? "text-[#4caf50]" : "text-green-600",
      medium: isDarkMode ? "text-[#ffc107]" : "text-yellow-600",
      hard: isDarkMode ? "text-[#f44336]" : "text-red-600",
    }
    return colors[difficulty as keyof typeof colors] || (isDarkMode ? "text-[#f5f5f5]" : "text-gray-800")
  }

  const getDifficultyBgColor = (difficulty: string) => {
    const colors = {
      easy: isDarkMode ? "bg-[#4caf50]" : "bg-green-500",
      medium: isDarkMode ? "bg-[#ffc107]" : "bg-yellow-500",
      hard: isDarkMode ? "bg-[#f44336]" : "bg-red-500",
    }
    return colors[difficulty as keyof typeof colors] || (isDarkMode ? "bg-blue-500" : "bg-blue-500")
  }

  return (
    <div className={`min-h-screen transition-all duration-500 p-4 ${isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-100"}`}>
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                onClick={() => router.push("/")}
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                    : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                } transition-all duration-300`}
              >
                <Home className="w-4 h-4 mr-2" />
                Ana Sayfa
              </Button>
            </motion.div>
            <motion.h1
              className={`text-4xl font-bold flex items-center gap-2 ${
                isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"
              }`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <BarChart3 className="w-8 h-8 text-[#2196f3]" />
              İstatistikler
            </motion.h1>
          </div>

          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`${
                isDarkMode
                  ? "bg-[#2e2e3e] border-gray-600 text-[#f5f5f5] hover:bg-[#3e3e4e]"
                  : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
              } transition-all duration-300`}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
          </motion.div>
        </motion.div>

        {stats.totalGames === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card
              className={`${
                isDarkMode
                  ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                  : "bg-white/80 backdrop-blur border-gray-200/50"
              } shadow-xl`}
            >
              <CardContent className="p-8 text-center">
                <BarChart3
                  className={`w-16 h-16 mx-auto mb-4 opacity-50 ${isDarkMode ? "text-[#2196f3]" : "text-blue-500"}`}
                />
                <h2 className={`text-2xl font-bold mb-2 ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                  Henüz İstatistik Yok!
                </h2>
                <p className={`mb-6 ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                  İstatistiklerini görmek için oyun oynamaya başla.
                </p>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => router.push("/game")}
                    className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] transition-all duration-300"
                  >
                    Oyuna Başla
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <>
            {/* General Statistics */}
            <motion.div
              className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              {[
                { icon: Target, value: stats.totalGames, label: "Toplam Oyun", color: "text-[#2196f3]" },
                {
                  icon: Trophy,
                  value: stats.bestScore.toLocaleString(),
                  label: "En Yüksek Skor",
                  color: "text-[#ffc107]",
                },
                { icon: Clock, value: formatTime(stats.fastestTime), label: "En Hızlı Süre", color: "text-[#4caf50]" },
                { icon: Zap, value: stats.streak, label: "Mevcut Seri", color: "text-[#9c27b0]" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  whileHover={{ scale: 1.05, y: -5 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.5 }}
                >
                  <Card
                    className={`${
                      isDarkMode
                        ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                        : "bg-white/80 backdrop-blur border-gray-200/50"
                    } transition-all duration-300 hover:shadow-lg`}
                  >
                    <CardContent className="p-4 text-center">
                      <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                      <div className={`text-2xl font-bold ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                        {stat.value}
                      </div>
                      <div className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>{stat.label}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>

            {/* Detailed Statistics */}
            <motion.div
              className="grid md:grid-cols-2 gap-6 mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7, duration: 0.5 }}
              >
                <Card
                  className={`${
                    isDarkMode
                      ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                      : "bg-white/80 backdrop-blur border-gray-200/50"
                  } shadow-lg h-full`}
                >
                  <CardHeader>
                    <CardTitle className={`flex items-center gap-2 ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                      <TrendingUp className="w-5 h-5 text-[#4caf50]" />
                      Performans Metrikleri
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { label: "Ortalama Süre", value: formatTime(stats.averageTime) },
                      { label: "Toplam Skor", value: stats.totalScore.toLocaleString() },
                      {
                        label: "Ortalama Skor",
                        value: Math.round(stats.totalScore / stats.totalGames).toLocaleString(),
                      },
                      { label: "Başarı Oranı", value: `${stats.winRate}%`, icon: Percent, color: "text-[#4caf50]" },
                    ].map((metric, index) => (
                      <motion.div
                        key={metric.label}
                        className="flex justify-between items-center"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.8 + index * 0.1, duration: 0.3 }}
                      >
                        <span className={`${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>{metric.label}:</span>
                        <span
                          className={`font-bold flex items-center gap-1 ${
                            metric.color || (isDarkMode ? "text-[#f5f5f5]" : "text-gray-800")
                          }`}
                        >
                          {metric.icon && <metric.icon className="w-4 h-4" />}
                          {metric.value}
                        </span>
                      </motion.div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7, duration: 0.5 }}
              >
                <Card
                  className={`${
                    isDarkMode
                      ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                      : "bg-white/80 backdrop-blur border-gray-200/50"
                  } shadow-lg h-full`}
                >
                  <CardHeader>
                    <CardTitle className={`flex items-center gap-2 ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                      <BarChart3 className="w-5 h-5 text-[#2196f3]" />
                      Zorluk Seviyesi Analizi
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries(stats.gamesPerDifficulty).map(([difficulty, count], index) => (
                      <motion.div
                        key={difficulty}
                        className="space-y-2"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.8 + index * 0.1, duration: 0.3 }}
                      >
                        <div className="flex justify-between items-center">
                          <span className={`font-semibold ${getDifficultyColor(difficulty)}`}>
                            {getDifficultyLabel(difficulty)}
                          </span>
                          <span className={`${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>{count} oyun</span>
                        </div>
                        <div className={`w-full ${isDarkMode ? "bg-[#1e1e2f]" : "bg-gray-200"} rounded-full h-2`}>
                          <motion.div
                            className={`h-2 rounded-full ${getDifficultyBgColor(difficulty)}`}
                            initial={{ width: 0 }}
                            animate={{ width: `${(count / stats.totalGames) * 100}%` }}
                            transition={{ delay: 0.9 + index * 0.1, duration: 0.5 }}
                          />
                        </div>
                        <div className={`text-right text-sm ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                          Ort. Skor: {stats.averageScorePerDifficulty[difficulty]?.toLocaleString() || 0}
                        </div>
                      </motion.div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>

            {/* Recent Games */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1, duration: 0.5 }}
            >
              <Card
                className={`${
                  isDarkMode
                    ? "bg-[#2e2e3e]/80 backdrop-blur border-gray-600/30"
                    : "bg-white/80 backdrop-blur border-gray-200/50"
                } shadow-xl`}
              >
                <CardHeader>
                  <CardTitle className={`flex items-center gap-2 ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                    <Clock className="w-5 h-5 text-[#2196f3]" />
                    Son Oyunlar
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats.recentGames.map((game, index) => (
                      <motion.div
                        key={`${game.date}-${index}`}
                        className={`flex items-center justify-between p-3 rounded-lg ${
                          isDarkMode ? "bg-[#1e1e2f]/50 hover:bg-[#1e1e2f]/80" : "bg-gray-50 hover:bg-white"
                        } transition-all duration-300`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.1 + index * 0.05, duration: 0.3 }}
                        whileHover={{ scale: 1.02, x: 5 }}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${getDifficultyBgColor(game.difficulty)}`} />
                          <div>
                            <div className={`font-semibold ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                              {getDifficultyLabel(game.difficulty)}
                            </div>
                            <div className={`text-sm ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                              {new Date(game.date).toLocaleDateString("tr-TR")}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`font-bold ${isDarkMode ? "text-[#f5f5f5]" : "text-gray-800"}`}>
                            {game.score.toLocaleString()}
                          </div>
                          <div className={`text-sm ${isDarkMode ? "text-blue-300" : "text-indigo-600"}`}>
                            {formatTime(game.time)}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Back to Game Button */}
            <motion.div
              className="text-center mt-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2, duration: 0.5 }}
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => router.push("/game")}
                  className="bg-gradient-to-r from-[#4caf50] to-[#2196f3] hover:from-[#45a049] hover:to-[#1976d2] text-lg px-8 py-3 transition-all duration-300"
                >
                  🎮 Oyuna Dön
                </Button>
              </motion.div>
            </motion.div>
          </>
        )}
      </div>
    </div>
  )
}
