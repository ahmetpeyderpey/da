import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Mayın Tarlası - Modern ve Eğlenceli Mayın Tarlası Oyunu",
  description: "Animasyonlu, sesli ve AI destekli modern mayın tarlası oyunu. Arkadaşlarınla yarış, skorunu paylaş!",
  keywords: "mayın tarlası, minesweeper, oyun, türkçe oyun, online oyun, modern oyun",
  authors: [{ name: "MayinTarlasi.net" }],
  creator: "MayinTarlasi.net",
  publisher: "MayinTarlasi.net",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    title: "Mayın Tarlası - Modern ve Eğlenceli Mayın Tarlası Oyunu",
    description: "Animasyonlu, sesli ve AI destekli modern mayın tarlası oyunu. Arkadaşlarınla yarış, skorunu paylaş!",
    url: "https://mayintarlasi.net",
    siteName: "MayinTarlasi.net",
    locale: "tr_TR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Mayın Tarlası - Modern ve Eğlenceli Mayın Tarlası Oyunu",
    description: "Animasyonlu, sesli ve AI destekli modern mayın tarlası oyunu. Arkadaşlarınla yarış, skorunu paylaş!",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
