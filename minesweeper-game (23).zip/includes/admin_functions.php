<?php
/**
 * Admin fonksiyonları
 */

// Admin oturum anahtarı
define('ADMIN_SESSION_KEY', 'mayin_tarlasi_admin');

// Varsayılan admin bilgileri
define('DEFAULT_ADMIN_USERNAME', 'admin');
define('DEFAULT_ADMIN_PASSWORD', 'admin123');

/**
 * Admin giriş kontrolü
 */
function isAdminLoggedIn() {
    return isset($_SESSION[ADMIN_SESSION_KEY]) && $_SESSION[ADMIN_SESSION_KEY] === true;
}

/**
 * Admin giriş işlemi
 */
function adminLogin($username, $password) {
    try {
        global $pdo;
        
        // Veritabanı bağlantısı varsa
        if (isset($pdo)) {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = :username LIMIT 1");
            $stmt->execute(['username' => $username]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION[ADMIN_SESSION_KEY] = true;
                return true;
            }
            
            // Eğer admin tablosu boşsa ve varsayılan bilgilerle giriş yapılıyorsa
            if (!$admin && $username === DEFAULT_ADMIN_USERNAME && $password === DEFAULT_ADMIN_PASSWORD) {
                // Varsayılan admin hesabını oluştur
                $hashedPassword = password_hash(DEFAULT_ADMIN_PASSWORD, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO admins (username, password, name, email, created_at) VALUES (:username, :password, 'Admin', 'admin@example.com', NOW())");
                $stmt->execute([
                    'username' => DEFAULT_ADMIN_USERNAME,
                    'password' => $hashedPassword
                ]);
                
                $_SESSION[ADMIN_SESSION_KEY] = true;
                return true;
            }
        } else {
            // Dosya tabanlı giriş
            if ($username === DEFAULT_ADMIN_USERNAME && $password === DEFAULT_ADMIN_PASSWORD) {
                $_SESSION[ADMIN_SESSION_KEY] = true;
                return true;
            }
        }
        
        return false;
    } catch (Exception $e) {
        // Hata durumunda varsayılan giriş
        if ($username === DEFAULT_ADMIN_USERNAME && $password === DEFAULT_ADMIN_PASSWORD) {
            $_SESSION[ADMIN_SESSION_KEY] = true;
            return true;
        }
        return false;
    }
}

/**
 * Admin çıkış işlemi
 */
function adminLogout() {
    if (isset($_SESSION[ADMIN_SESSION_KEY])) {
        unset($_SESSION[ADMIN_SESSION_KEY]);
    }
    return true;
}

/**
 * Admin istatistiklerini getir
 */
function getAdminStats() {
    try {
        global $pdo;
        
        // Varsayılan istatistikler
        $stats = [
            'total_users' => 0,
            'total_games' => 0,
            'highest_score' => 0,
            'today_games' => 0,
            'difficulty_distribution' => [
                'easy' => 0,
                'medium' => 0,
                'hard' => 0,
                'custom' => 0
            ],
            'weekly_games' => [],
            'recent_games' => []
        ];
        
        // Veritabanı bağlantısı varsa
        if (isset($pdo)) {
            // Toplam kullanıcı sayısı
            $stmt = $pdo->query("SELECT COUNT(DISTINCT nickname) as total FROM scores");
            $stats['total_users'] = $stmt->fetchColumn();
            
            // Toplam oyun sayısı
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM scores");
            $stats['total_games'] = $stmt->fetchColumn();
            
            // En yüksek skor
            $stmt = $pdo->query("SELECT MAX(score) as highest FROM scores");
            $stats['highest_score'] = $stmt->fetchColumn() ?: 0;
            
            // Bugünkü oyunlar
            $stmt = $pdo->query("SELECT COUNT(*) as today FROM scores WHERE DATE(date) = CURDATE()");
            $stats['today_games'] = $stmt->fetchColumn();
            
            // Zorluk seviyesi dağılımı
            $stmt = $pdo->query("SELECT difficulty, COUNT(*) as count FROM scores GROUP BY difficulty");
            $difficulties = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($difficulties as $diff) {
                $stats['difficulty_distribution'][$diff['difficulty']] = (int)$diff['count'];
            }
            
            // Haftalık oyun istatistikleri
            $stmt = $pdo->query("
                SELECT 
                    DATE_FORMAT(date, '%d.%m') as day,
                    COUNT(*) as count
                FROM 
                    scores
                WHERE 
                    date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY 
                    DATE_FORMAT(date, '%Y-%m-%d')
                ORDER BY 
                    date ASC
            ");
            $weekly = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($weekly as $day) {
                $stats['weekly_games'][$day['day']] = (int)$day['count'];
            }
            
            // Son oyunlar
            $stmt = $pdo->query("
                SELECT 
                    nickname, 
                    difficulty, 
                    time, 
                    score, 
                    date
                FROM 
                    scores
                ORDER BY 
                    date DESC
                LIMIT 10
            ");
            $stats['recent_games'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Dosya tabanlı istatistikler
            $scores = getScores();
            
            if (!empty($scores)) {
                $stats['total_users'] = count(array_unique(array_column($scores, 'nickname')));
                $stats['total_games'] = count($scores);
                $stats['highest_score'] = max(array_column($scores, 'score'));
                
                // Bugünkü oyunlar
                $today = date('Y-m-d');
                $todayGames = array_filter($scores, function($score) use ($today) {
                    return substr($score['date'], 0, 10) === $today;
                });
                $stats['today_games'] = count($todayGames);
                
                // Zorluk seviyesi dağılımı
                foreach ($scores as $score) {
                    $diff = $score['difficulty'];
                    $stats['difficulty_distribution'][$diff] = ($stats['difficulty_distribution'][$diff] ?? 0) + 1;
                }
                
                // Haftalık oyun istatistikleri
                $weekStart = strtotime('-7 days');
                $weeklyGames = [];
                foreach ($scores as $score) {
                    $scoreDate = strtotime($score['date']);
                    if ($scoreDate >= $weekStart) {
                        $day = date('d.m', $scoreDate);
                        $weeklyGames[$day] = ($weeklyGames[$day] ?? 0) + 1;
                    }
                }
                $stats['weekly_games'] = $weeklyGames;
                
                // Son oyunlar
                $stats['recent_games'] = array_slice($scores, 0, 10);
            }
        }
        
        return $stats;
    } catch (Exception $e) {
        // Hata durumunda boş istatistikler
        return [
            'total_users' => 0,
            'total_games' => 0,
            'highest_score' => 0,
            'today_games' => 0,
            'difficulty_distribution' => [
                'easy' => 0,
                'medium' => 0,
                'hard' => 0,
                'custom' => 0
            ],
            'weekly_games' => [],
            'recent_games' => []
        ];
    }
}

/**
 * Zorluk seviyesi rengini getir
 */
function getDifficultyColor($difficulty) {
    $colors = [
        'easy' => 'green',
        'medium' => 'yellow',
        'hard' => 'red',
        'custom' => 'purple'
    ];
    return $colors[$difficulty] ?? 'blue';
}

/**
 * Site ayarlarını getir
 */
function getSiteSettings() {
    try {
        global $pdo;
        
        // Varsayılan ayarlar
        $settings = [
            'site_title' => 'Mayın Tarlası',
            'site_description' => 'Modern Mayın Tarlası Oyunu',
            'theme_color' => '#2196f3',
            'allow_custom_difficulty' => true,
            'max_leaderboard_entries' => 100,
            'show_ai_button' => true,
            'enable_sound' => true,
            'enable_animations' => true
        ];
        
        // Veritabanı bağlantısı varsa
        if (isset($pdo)) {
            $stmt = $pdo->query("SELECT * FROM settings");
            $dbSettings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
            
            if (!empty($dbSettings)) {
                foreach ($dbSettings as $key => $value) {
                    // Boolean değerleri dönüştür
                    if ($value === '0' || $value === '1') {
                        $settings[$key] = (bool)$value;
                    } else {
                        $settings[$key] = $value;
                    }
                }
            }
        } else {
            // Dosya tabanlı ayarlar
            $settingsFile = 'data/settings.json';
            if (file_exists($settingsFile)) {
                $fileSettings = json_decode(file_get_contents($settingsFile), true);
                if (is_array($fileSettings)) {
                    $settings = array_merge($settings, $fileSettings);
                }
            }
        }
        
        return $settings;
    } catch (Exception $e) {
        // Hata durumunda varsayılan ayarlar
        return [
            'site_title' => 'Mayın Tarlası',
            'site_description' => 'Modern Mayın Tarlası Oyunu',
            'theme_color' => '#2196f3',
            'allow_custom_difficulty' => true,
            'max_leaderboard_entries' => 100,
            'show_ai_button' => true,
            'enable_sound' => true,
            'enable_animations' => true
        ];
    }
}

/**
 * Site ayarlarını kaydet
 */
function saveSiteSettings($settings) {
    try {
        global $pdo;
        
        // Veritabanı bağlantısı varsa
        if (isset($pdo)) {
            // Önce tabloyu temizle
            $pdo->exec("DELETE FROM settings");
            
            // Yeni ayarları ekle
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (:key, :value)");
            
            foreach ($settings as $key => $value) {
                // Boolean değerleri dönüştür
                if (is_bool($value)) {
                    $value = $value ? '1' : '0';
                }
                
                $stmt->execute([
                    'key' => $key,
                    'value' => $value
                ]);
            }
        } else {
            // Dosya tabanlı ayarlar
            $settingsFile = 'data/settings.json';
            file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT));
        }
        
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>
