<?php
// Oyun mantığı

// Yeni oyun başlatma
function initializeGame($rows, $cols, $mines) {
    // Oyun tahtasını oluştur
    $board = [];
    for ($r = 0; $r < $rows; $r++) {
        for ($c = 0; $c < $cols; $c++) {
            $board[$r][$c] = [
                'is_mine' => false,
                'is_revealed' => false,
                'is_flagged' => false,
                'is_exploded' => false,
                'neighbor_mines' => 0
            ];
        }
    }
    
    // Mayınları yerleştir
    $mineCount = 0;
    while ($mineCount < $mines) {
        $r = rand(0, $rows - 1);
        $c = rand(0, $cols - 1);
        
        if (!$board[$r][$c]['is_mine']) {
            $board[$r][$c]['is_mine'] = true;
            $mineCount++;
            
            // Komşu hücrelerin mayın sayısını güncelle
            for ($dr = -1; $dr <= 1; $dr++) {
                for ($dc = -1; $dc <= 1; $dc++) {
                    $nr = $r + $dr;
                    $nc = $c + $dc;
                    
                    if ($nr >= 0 && $nr < $rows && $nc >= 0 && $nc < $cols) {
                        $board[$nr][$nc]['neighbor_mines']++;
                    }
                }
            }
        }
    }
    
    // Oyun durumunu sıfırla
    $_SESSION['game_board'] = $board;
    $_SESSION['game_state'] = 'playing';
    $_SESSION['game_time'] = 0;
    $_SESSION['game_score'] = 0;
    $_SESSION['flag_count'] = 0;
    $_SESSION['revealed_cells'] = 0;
    $_SESSION['streak'] = 0;
    $_SESSION['combo'] = 0;
    $_SESSION['hints_used'] = 0;
    
    return $board;
}

// Hücre içeriğini belirleme
function getCellContent($cell) {
    if ($cell['is_flagged']) {
        return '🚩';
    } elseif ($cell['is_revealed']) {
        if ($cell['is_mine']) {
            return '💣';
        } elseif ($cell['neighbor_mines'] > 0) {
            return $cell['neighbor_mines'];
        }
    }
    return '';
}

// Hücre açma
function revealCell($row, $col) {
    if (!isset($_SESSION['game_board'])) {
        return ['success' => false, 'message' => 'Oyun başlatılmamış'];
    }
    
    $board = $_SESSION['game_board'];
    $rows = count($board);
    $cols = count($board[0]);
    
    // Geçersiz koordinat
    if ($row < 0 || $row >= $rows || $col < 0 || $col >= $cols) {
        return ['success' => false, 'message' => 'Geçersiz koordinat'];
    }
    
    // Zaten açılmış veya bayrak konulmuş
    if ($board[$row][$col]['is_revealed'] || $board[$row][$col]['is_flagged']) {
        return ['success' => false, 'message' => 'Bu hücre zaten açılmış veya bayrak konulmuş'];
    }
    
    // Oyun durumu
    $gameState = $_SESSION['game_state'];
    if ($gameState !== 'playing') {
        return ['success' => false, 'message' => 'Oyun şu anda ' . $gameState . ' durumunda'];
    }
    
    // Hücreyi aç
    $board[$row][$col]['is_revealed'] = true;
    $_SESSION['revealed_cells']++;
    
    // Mayına basıldıysa
    if ($board[$row][$col]['is_mine']) {
        $board[$row][$col]['is_exploded'] = true;
        $_SESSION['game_state'] = 'lost';
        
        // Tüm mayınları göster
        for ($r = 0; $r < $rows; $r++) {
            for ($c = 0; $c < $cols; $c++) {
                if ($board[$r][$c]['is_mine'] && !$board[$r][$c]['is_flagged']) {
                    $board[$r][$c]['is_revealed'] = true;
                }
            }
        }
        
        $_SESSION['game_board'] = $board;
        return [
            'success' => true,
            'game_over' => true,
            'won' => false,
            'message' => 'Mayına bastınız! Oyun bitti.'
        ];
    }
    
    // Boş hücre açıldıysa komşuları da aç
    if ($board[$row][$col]['neighbor_mines'] === 0) {
        $queue = [[$row, $col]];
        while (!empty($queue)) {
            list($r, $c) = array_shift($queue);
            
            for ($dr = -1; $dr <= 1; $dr++) {
                for ($dc = -1; $dc <= 1; $dc++) {
                    $nr = $r + $dr;
                    $nc = $c + $dc;
                    
                    if ($nr >= 0 && $nr < $rows && $nc >= 0 && $nc < $cols &&
                        !$board[$nr][$nc]['is_revealed'] && !$board[$nr][$nc]['is_flagged']) {
                        
                        $board[$nr][$nc]['is_revealed'] = true;
                        $_SESSION['revealed_cells']++;
                        
                        if ($board[$nr][$nc]['neighbor_mines'] === 0) {
                            $queue[] = [$nr, $nc];
                        }
                    }
                }
            }
        }
    }
    
    // Skor hesapla
    $_SESSION['streak']++;
    $_SESSION['combo'] = min($_SESSION['combo'] + 1, 10);
    $basePoints = 10;
    $streakBonus = $_SESSION['streak'] * 2;
    $comboBonus = $_SESSION['combo'] * 5;
    $points = $basePoints + $streakBonus + $comboBonus;
    $_SESSION['game_score'] += $points;
    
    // Kazanma kontrolü
    $totalCells = $rows * $cols;
    $totalMines = 0;
    for ($r = 0; $r < $rows; $r++) {
        for ($c = 0; $c < $cols; $c++) {
            if ($board[$r][$c]['is_mine']) {
                $totalMines++;
            }
        }
    }
    
    if ($_SESSION['revealed_cells'] === $totalCells - $totalMines) {
        $_SESSION['game_state'] = 'won';
        
        // Tüm mayınlara bayrak koy
        for ($r = 0; $r < $rows; $r++) {
            for ($c = 0; $c < $cols; $c++) {
                if ($board[$r][$c]['is_mine'] && !$board[$r][$c]['is_flagged']) {
                    $board[$r][$c]['is_flagged'] = true;
                    $_SESSION['flag_count']++;
                }
            }
        }
        
        $_SESSION['game_board'] = $board;
        return [
            'success' => true,
            'game_over' => true,
            'won' => true,
            'message' => 'Tebrikler! Oyunu kazandınız!'
        ];
    }
    
    $_SESSION['game_board'] = $board;
    return [
        'success' => true,
        'game_over' => false,
        'points' => $points,
        'streak' => $_SESSION['streak'],
        'combo' => $_SESSION['combo'],
        'score' => $_SESSION['game_score']
    ];
}

// Bayrak koyma/kaldırma
function toggleFlag($row, $col) {
    if (!isset($_SESSION['game_board'])) {
        return ['success' => false, 'message' => 'Oyun başlatılmamış'];
    }
    
    $board = $_SESSION['game_board'];
    $rows = count($board);
    $cols = count($board[0]);
    
    // Geçersiz koordinat
    if ($row < 0 || $row >= $rows || $col < 0 || $col >= $cols) {
        return ['success' => false, 'message' => 'Geçersiz koordinat'];
    }
    
    // Zaten açılmış
    if ($board[$row][$col]['is_revealed']) {
        return ['success' => false, 'message' => 'Bu hücre zaten açılmış'];
    }
    
    // Oyun durumu
    $gameState = $_SESSION['game_state'];
    if ($gameState !== 'playing') {
        return ['success' => false, 'message' => 'Oyun şu anda ' . $gameState . ' durumunda'];
    }
    
    // Bayrak koy/kaldır
    $board[$row][$col]['is_flagged'] = !$board[$row][$col]['is_flagged'];
    
    // Bayrak sayısını güncelle
    if ($board[$row][$col]['is_flagged']) {
        $_SESSION['flag_count']++;
    } else {
        $_SESSION['flag_count']--;
    }
    
    $_SESSION['game_board'] = $board;
    return [
        'success' => true,
        'is_flagged' => $board[$row][$col]['is_flagged'],
        'flag_count' => $_SESSION['flag_count']
    ];
}
?>
