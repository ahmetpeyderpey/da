<?php
// Basit konfigürasyon dosyası
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone ayarı
date_default_timezone_set('Europe/Istanbul');

// Karakter kodlaması
header('Content-Type: text/html; charset=utf-8');

// Dosya tabanlı veri saklama
define('SCORES_FILE', 'data/scores.json');
define('STATS_FILE', 'data/stats.json');

// Data klasörünü oluştur
if (!file_exists('data')) {
    mkdir('data', 0755, true);
}

// Scores dosyasını oluştur
if (!file_exists(SCORES_FILE)) {
    file_put_contents(SCORES_FILE, json_encode([]));
}

// Stats dosyasını oluştur
if (!file_exists(STATS_FILE)) {
    file_put_contents(STATS_FILE, json_encode([]));
}
?>
