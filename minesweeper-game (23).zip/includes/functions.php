<?php
// Temel fonksiyonlar

// Zaman formatı
function formatTime($seconds) {
    $minutes = floor($seconds / 60);
    $seconds = $seconds % 60;
    return sprintf('%02d:%02d', $minutes, $seconds);
}

// POST verisi alma
function getPost($key, $default = '') {
    return isset($_POST[$key]) ? trim($_POST[$key]) : $default;
}

// GET verisi alma
function getGet($key, $default = '') {
    return isset($_GET[$key]) ? trim($_GET[$key]) : $default;
}

// Hücre sınıfı belirleme
function getCellClass($cell, $isDarkMode = false) {
    $baseClass = 'cell';
    
    if ($cell['is_revealed']) {
        $baseClass .= ' revealed';
        
        if ($cell['is_mine']) {
            $baseClass .= ' mine';
            if ($cell['is_exploded']) {
                $baseClass .= ' exploded';
            }
        } else {
            $baseClass .= ' safe';
            if ($cell['neighbor_mines'] > 0) {
                $baseClass .= ' neighbors-' . $cell['neighbor_mines'];
            } else {
                $baseClass .= ' empty';
            }
        }
    } else {
        if ($cell['is_flagged']) {
            $baseClass .= ' flagged';
        }
    }
    
    return $baseClass;
}

// Skor kaydetme
function saveScore($nickname, $difficulty, $time, $score) {
    $scores = [];
    if (file_exists(SCORES_FILE)) {
        $scores = json_decode(file_get_contents(SCORES_FILE), true) ?: [];
    }
    
    $scores[] = [
        'nickname' => $nickname,
        'difficulty' => $difficulty,
        'time' => $time,
        'score' => $score,
        'date' => date('Y-m-d H:i:s')
    ];
    
    // Skorları sırala
    usort($scores, function($a, $b) {
        return $b['score'] - $a['score'];
    });
    
    // En iyi 100 skoru sakla
    $scores = array_slice($scores, 0, 100);
    
    file_put_contents(SCORES_FILE, json_encode($scores));
    
    return true;
}

// İstatistikleri güncelleme
function updateStats($nickname, $won, $score, $time) {
    $stats = [];
    if (file_exists(STATS_FILE)) {
        $stats = json_decode(file_get_contents(STATS_FILE), true) ?: [];
    }
    
    if (!isset($stats[$nickname])) {
        $stats[$nickname] = [
            'total_games' => 0,
            'total_wins' => 0,
            'total_score' => 0,
            'best_time' => 0,
            'last_played' => ''
        ];
    }
    
    $stats[$nickname]['total_games']++;
    if ($won) {
        $stats[$nickname]['total_wins']++;
        $stats[$nickname]['total_score'] += $score;
        
        if ($stats[$nickname]['best_time'] == 0 || $time < $stats[$nickname]['best_time']) {
            $stats[$nickname]['best_time'] = $time;
        }
    }
    
    $stats[$nickname]['last_played'] = date('Y-m-d H:i:s');
    
    file_put_contents(STATS_FILE, json_encode($stats));
    
    return true;
}
?>
