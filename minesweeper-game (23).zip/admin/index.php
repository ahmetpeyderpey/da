<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/admin_functions.php';

// Admin girişi kontrolü
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Tema ayarı
$isDarkMode = isset($_COOKIE['admin_dark_mode']) ? $_COOKIE['admin_dark_mode'] === 'true' : true;

// İstatistikleri getir
$stats = getAdminStats();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mayın Tarlası - Admin Paneli</title>
    <link rel="stylesheet" href="../assets/css/tailwind.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="<?php echo $isDarkMode ? 'dark-mode' : 'light-mode'; ?>">
    <div class="flex h-screen bg-gray-100 dark:bg-gray-900">
        <!-- Sidebar -->
        <?php include 'partials/sidebar.php'; ?>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <?php include 'partials/header.php'; ?>

            <!-- Main -->
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900 p-6">
                <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">
                    Dashboard
                </h1>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-blue-500 bg-opacity-10 text-blue-500">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="font-semibold text-gray-500 dark:text-gray-400">Toplam Kullanıcı</h2>
                                <p class="text-2xl font-bold text-gray-800 dark:text-white"><?php echo $stats['total_users']; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-green-500 bg-opacity-10 text-green-500">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="font-semibold text-gray-500 dark:text-gray-400">Toplam Oyun</h2>
                                <p class="text-2xl font-bold text-gray-800 dark:text-white"><?php echo $stats['total_games']; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-yellow-500 bg-opacity-10 text-yellow-500">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="font-semibold text-gray-500 dark:text-gray-400">En Yüksek Skor</h2>
                                <p class="text-2xl font-bold text-gray-800 dark:text-white"><?php echo number_format($stats['highest_score']); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-red-500 bg-opacity-10 text-red-500">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <h2 class="font-semibold text-gray-500 dark:text-gray-400">Bugünkü Oyunlar</h2>
                                <p class="text-2xl font-bold text-gray-800 dark:text-white"><?php echo $stats['today_games']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                            Zorluk Seviyesi Dağılımı
                        </h2>
                        <div class="h-80">
                            <canvas id="difficultyChart"></canvas>
                        </div>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                            Haftalık Oyun İstatistikleri
                        </h2>
                        <div class="h-80">
                            <canvas id="weeklyChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Games -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                        Son Oyunlar
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="w-full table-auto">
                            <thead>
                                <tr class="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 uppercase text-sm leading-normal">
                                    <th class="py-3 px-6 text-left">Kullanıcı</th>
                                    <th class="py-3 px-6 text-left">Zorluk</th>
                                    <th class="py-3 px-6 text-center">Süre</th>
                                    <th class="py-3 px-6 text-center">Skor</th>
                                    <th class="py-3 px-6 text-center">Tarih</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 dark:text-gray-400">
                                <?php foreach ($stats['recent_games'] as $game): ?>
                                <tr class="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700">
                                    <td class="py-3 px-6 text-left whitespace-nowrap">
                                        <?php echo htmlspecialchars($game['nickname']); ?>
                                    </td>
                                    <td class="py-3 px-6 text-left">
                                        <span class="bg-<?php echo getDifficultyColor($game['difficulty']); ?>-200 text-<?php echo getDifficultyColor($game['difficulty']); ?>-800 py-1 px-3 rounded-full text-xs">
                                            <?php echo getDifficultyLabel($game['difficulty']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-6 text-center">
                                        <?php echo formatTime($game['time']); ?>
                                    </td>
                                    <td class="py-3 px-6 text-center">
                                        <?php echo number_format($game['score']); ?>
                                    </td>
                                    <td class="py-3 px-6 text-center">
                                        <?php echo date('d.m.Y H:i', strtotime($game['date'])); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Tema değiştirme
        document.getElementById('theme-toggle').addEventListener('click', function() {
            const isDarkMode = document.body.classList.contains('dark-mode');
            document.body.classList.toggle('dark-mode');
            document.body.classList.toggle('light-mode');
            
            // Cookie'ye kaydet
            document.cookie = `admin_dark_mode=${!isDarkMode}; path=/; max-age=31536000`;
        });

        // Sidebar toggle (mobil)
        document.getElementById('sidebar-toggle').addEventListener('click', function() {
            document.querySelector('aside').classList.toggle('show');
        });

        // Zorluk seviyesi dağılımı grafiği
        const difficultyData = <?php echo json_encode($stats['difficulty_distribution']); ?>;
        const difficultyCtx = document.getElementById('difficultyChart').getContext('2d');
        new Chart(difficultyCtx, {
            type: 'pie',
            data: {
                labels: Object.keys(difficultyData).map(key => getDifficultyLabel(key)),
                datasets: [{
                    data: Object.values(difficultyData),
                    backgroundColor: [
                        'rgba(76, 175, 80, 0.6)',
                        'rgba(255, 193, 7, 0.6)',
                        'rgba(244, 67, 54, 0.6)',
                        'rgba(156, 39, 176, 0.6)'
                    ],
                    borderColor: [
                        'rgba(76, 175, 80, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(244, 67, 54, 1)',
                        'rgba(156, 39, 176, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: document.body.classList.contains('dark-mode') ? '#fff' : '#333'
                        }
                    }
                }
            }
        });

        // Haftalık oyun istatistikleri grafiği
        const weeklyData = <?php echo json_encode($stats['weekly_games']); ?>;
        const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
        new Chart(weeklyCtx, {
            type: 'line',
            data: {
                labels: Object.keys(weeklyData),
                datasets: [{
                    label: 'Oyun Sayısı',
                    data: Object.values(weeklyData),
                    backgroundColor: 'rgba(33, 150, 243, 0.2)',
                    borderColor: 'rgba(33, 150, 243, 1)',
                    borderWidth: 2,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: document.body.classList.contains('dark-mode') ? '#fff' : '#333'
                        },
                        grid: {
                            color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: document.body.classList.contains('dark-mode') ? '#fff' : '#333'
                        },
                        grid: {
                            color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: document.body.classList.contains('dark-mode') ? '#fff' : '#333'
                        }
                    }
                }
            }
        });

        // Zorluk seviyesi etiketini getir
        function getDifficultyLabel(difficulty) {
            const labels = {
                'easy': 'Kolay',
                'medium': 'Orta',
                'hard': 'Zor',
                'custom': 'Özel'
            };
            return labels[difficulty] || difficulty;
        }
    </script>
</body>
</html>
