<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/admin_functions.php';

// Admin çıkış işlemi
adminLogout();

// Giriş sayfasına yönlendir
header('Location: login.php');
exit;
?>
