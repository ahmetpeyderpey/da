<?php
require_once '../includes/config.php';

// Session'ı güvenli şekilde başlat
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Giriş formu ve doğrulama işlemleri burada olacak
?>
