<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendErrorResponse('Sadece POST istekleri kabul edilir', 405);
}

$safeCell = findSafeCell();

if ($safeCell) {
    sendSuccessResponse([
        'move' => [
            'row' => $safeCell[0],
            'col' => $safeCell[1]
        ]
    ], 'AI hamlesi bulundu');
} else {
    sendErrorResponse('Güvenli hücre bulunamadı');
}
?>
