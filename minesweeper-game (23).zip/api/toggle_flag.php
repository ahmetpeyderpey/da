<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu']);
    exit;
}

$row = isset($_POST['row']) ? intval($_POST['row']) : -1;
$col = isset($_POST['col']) ? intval($_POST['col']) : -1;

$result = toggleFlag($row, $col);

echo json_encode($result);
?>
