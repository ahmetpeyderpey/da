<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

// Oyun durumunu kontrol et
if (!isset($_SESSION['game_board']) || $_SESSION['game_state'] !== 'playing') {
    sendErrorResponse('Geçersiz oyun durumu');
}

// İpucu sayısını kontrol et
$hintsUsed = isset($_SESSION['hints_used']) ? $_SESSION['hints_used'] : 0;

if ($hintsUsed >= 3) {
    sendErrorResponse('İpucu hakkınız kalmadı');
}

// Güvenli bir hücre bul
$safeCell = findSafeCell();

if (!$safeCell) {
    sendErrorResponse('Güvenli hücre bulunamadı');
}

// İpucu kullanımını kaydet
$_SESSION['hints_used'] = $hintsUsed + 1;

// Başarılı yanıt gönder
sendSuccessResponse([
    'hint' => [
        'row' => $safeCell[0],
        'col' => $safeCell[1]
    ],
    'hints_used' => $_SESSION['hints_used']
]);
?>
