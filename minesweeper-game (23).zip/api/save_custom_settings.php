<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendErrorResponse('Sadece POST istekleri kabul edilir', 405);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['rows']) || !isset($input['cols']) || !isset($input['mines'])) {
    sendErrorResponse('Rows, cols ve mines parametreleri gerekli');
}

$rows = intval($input['rows']);
$cols = intval($input['cols']);
$mines = intval($input['mines']);

// Validasyon
if ($rows < 5 || $rows > 30) {
    sendErrorResponse('Satır sayısı 5-30 arasında olmalıdır');
}

if ($cols < 5 || $cols > 50) {
    sendErrorResponse('Sütun sayısı 5-50 arasında olmalıdır');
}

$maxMines = ($rows * $cols) - 1;
if ($mines < 1 || $mines > $maxMines) {
    sendErrorResponse("Mayın sayısı 1-{$maxMines} arasında olmalıdır");
}

// Ayarları kaydet
$_SESSION['custom_settings'] = [
    'rows' => $rows,
    'cols' => $cols,
    'mines' => $mines
];

$_SESSION['difficulty'] = 'custom';

// Yeni oyun başlat
$board = initializeGame($rows, $cols, $mines);

sendSuccessResponse(['board' => $board], 'Özel ayarlar kaydedildi ve yeni oyun başlatıldı');
?>
