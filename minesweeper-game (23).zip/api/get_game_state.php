<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Oyun durumunu kontrol et
if (!isset($_SESSION['game_board'])) {
    sendErrorResponse('Geçersiz oyun durumu');
}

// Oyun süresini güncelle
$gameTime = updateGameTime();

// Oyun durumunu gönder
sendSuccessResponse([
    'game_state' => $_SESSION['game_state'],
    'time' => $gameTime,
    'time_formatted' => formatTime($gameTime),
    'score' => $_SESSION['game_score'] ?? 0,
    'flag_count' => $_SESSION['flag_count'] ?? 0,
    'mines' => $_SESSION['game_mines'] ?? 0,
    'mines_left' => ($_SESSION['game_mines'] ?? 0) - ($_SESSION['flag_count'] ?? 0),
    'revealed_cells' => $_SESSION['revealed_cells'] ?? 0,
    'combo' => $_SESSION['combo'] ?? 0,
    'streak' => $_SESSION['streak'] ?? 0,
    'hints_used' => $_SESSION['hints_used'] ?? 0,
    'power_ups_used' => $_SESSION['power_ups_used'] ?? 0
]);
?>
