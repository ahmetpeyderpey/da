<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

// JSON verisi al
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Oyun durumunu kontrol et
if (!isset($_SESSION['game_board']) || $_SESSION['game_state'] !== 'playing') {
    sendErrorResponse('Geçersiz oyun durumu');
}

// Power-up türünü kontrol et
$power = isset($data['power']) ? $data['power'] : '';

if ($power === 'reveal') {
    // Güvenli bir hücre bul
    $safeCell = findSafeCell();
    
    if (!$safeCell) {
        sendErrorResponse('Güvenli hücre bulunamadı');
    }
    
    // Power-up kullanımını kaydet
    $_SESSION['power_ups_used'] = ($_SESSION['power_ups_used'] ?? 0) + 1;
    
    // Başarılı yanıt gönder
    sendSuccessResponse([
        'cell' => [
            'row' => $safeCell[0],
            'col' => $safeCell[1]
        ],
        'power_ups_used' => $_SESSION['power_ups_used']
    ]);
} else {
    sendErrorResponse('Geçersiz power-up türü');
}
?>
