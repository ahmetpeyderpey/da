<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Oyun durumunu kontrol et
if (!isset($_SESSION['game_board']) || $_SESSION['game_state'] !== 'paused') {
    sendErrorResponse('Geçersiz oyun durumu');
}

// Oyun süresini güncelle
if (isset($_SESSION['game_elapsed_time'])) {
    $_SESSION['game_start_time'] = time() - $_SESSION['game_elapsed_time'];
    unset($_SESSION['game_pause_time']);
    unset($_SESSION['game_elapsed_time']);
}

// Oyun durumunu güncelle
$_SESSION['game_state'] = 'playing';

// Başarılı yanıt gönder
sendSuccessResponse([
    'message' => 'Oyun devam ediyor'
]);
?>
