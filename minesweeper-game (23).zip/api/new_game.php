<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/game_logic.php';

header('Content-Type: application/json');

// Zorluk seviyesi
$difficulty = isset($_SESSION['difficulty']) ? $_SESSION['difficulty'] : 'medium';

// Oyun ayarları
$difficulties = [
    'easy' => ['rows' => 9, 'cols' => 9, 'mines' => 10],
    'medium' => ['rows' => 16, 'cols' => 16, 'mines' => 40],
    'hard' => ['rows' => 16, 'cols' => 30, 'mines' => 99]
];

$gameSettings = $difficulties[$difficulty];

// Yeni oyun başlat
$board = initializeGame($gameSettings['rows'], $gameSettings['cols'], $gameSettings['mines']);

// Oyun başlangıç zamanını kaydet
$_SESSION['game_start_time'] = time();

echo json_encode(['success' => true, 'message' => 'Yeni oyun başlatıldı']);
?>
