<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu']);
    exit;
}

$difficulty = isset($_POST['difficulty']) ? $_POST['difficulty'] : 'medium';

// Geçerli zorluk seviyesi kontrolü
$validDifficulties = ['easy', 'medium', 'hard'];
if (!in_array($difficulty, $validDifficulties)) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz zorluk seviyesi']);
    exit;
}

// Zorluk seviyesini kaydet
$_SESSION['difficulty'] = $difficulty;

// Oyun durumunu sıfırla
unset($_SESSION['game_board']);
unset($_SESSION['game_state']);
unset($_SESSION['game_time']);
unset($_SESSION['game_score']);
unset($_SESSION['flag_count']);
unset($_SESSION['revealed_cells']);
unset($_SESSION['streak']);
unset($_SESSION['combo']);
unset($_SESSION['hints_used']);

echo json_encode(['success' => true, 'message' => 'Zorluk seviyesi değiştirildi']);
?>
